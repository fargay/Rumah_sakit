
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Clock, 
  Users, 
  Award,
  Stethoscope,
  Calendar,
  MapPin,
  Phone,
  UserPlus,
  FileText,
  Activity,
  Shield,
  Star,
  CheckCircle
} from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => {
  const services = [
    {
      title: "Instalasi Gawat Darurat",
      description: "Layanan 24 jam dengan tim medis berpengalaman",
      icon: Activity,
      link: "/igd",
      urgent: true
    },
    {
      title: "Rawat Jalan",
      description: "Konsultasi dengan dokter spesialis",
      icon: Stethoscope,
      link: "/informasi-rawat-jalan"
    },
    {
      title: "Rawat Inap",
      description: "Fasilitas kamar yang nyaman dan lengkap",
      icon: Users,
      link: "/informasi-rawat-inap"
    },
    {
      title: "Laboratorium",
      description: "Pemeriksaan lab dengan teknologi modern",
      icon: FileText,
      link: "/layanan-medis"
    }
  ];

  const quickActions = [
    {
      title: "Pendaftaran Online",
      description: "Daftar sebagai pasien baru",
      icon: UserPlus,
      link: "/pendaftaran-online",
      variant: "default" as const
    },
    {
      title: "Jadwal Dokter",
      description: "Lihat jadwal praktik dokter",
      icon: Calendar,
      link: "/jadwal-praktik",
      variant: "outline" as const
    },
    {
      title: "Konsultasi Online",
      description: "Konsultasi dengan dokter online",
      icon: Activity,
      link: "/konsultasi-online",
      variant: "secondary" as const
    }
  ];

  const features = [
    {
      title: "Teknologi Terdepan",
      description: "Menggunakan peralatan medis terkini dan canggih",
      icon: Award
    },
    {
      title: "Tim Medis Profesional",
      description: "Dokter dan perawat berpengalaman dan tersertifikasi",
      icon: Users
    },
    {
      title: "Pelayanan 24 Jam",
      description: "Siap melayani kapan saja Anda membutuhkan",
      icon: Clock
    },
    {
      title: "Keamanan Data",
      description: "Sistem keamanan data pasien yang terjamin",
      icon: Shield
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-6 bg-medical-gradient text-white">
        <div className="container mx-auto text-center">
          <div className="animate-fade-in">
            <Badge className="mb-4 bg-white/20 text-white border-white/30">
              🏥 Rumah Sakit Terpercaya
            </Badge>
            <h1 className="text-5xl font-bold mb-6">
              RS Sehat Digital Indonesia
            </h1>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Memberikan pelayanan kesehatan terbaik dengan teknologi modern dan tim medis yang profesional untuk kesehatan keluarga Indonesia
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <Link to="/pendaftaran-online">
                  <UserPlus className="w-5 h-5 mr-2" />
                  Daftar Sekarang
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-medical-600" asChild>
                <Link to="/kontak-kami">
                  <Phone className="w-5 h-5 mr-2" />
                  Hubungi Kami
                </Link>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Stats */}
        <div className="container mx-auto mt-16 grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { number: "25+", label: "Tahun Pengalaman" },
            { number: "50+", label: "Dokter Spesialis" },
            { number: "10,000+", label: "Pasien Terlayani" },
            { number: "24/7", label: "Layanan Darurat" }
          ].map((stat, index) => (
            <div key={index} className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl font-bold mb-2">{stat.number}</div>
              <div className="text-sm opacity-90">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-16 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Aksi Cepat</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Akses layanan rumah sakit dengan cepat dan mudah
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickActions.map((action, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="text-center">
                  <action.icon className="w-12 h-12 mx-auto mb-4 text-medical-600" />
                  <CardTitle>{action.title}</CardTitle>
                  <CardDescription>{action.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" variant={action.variant} asChild>
                    <Link to={action.link}>
                      Akses Sekarang
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 px-6 bg-hospital-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Layanan Unggulan</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Beragam layanan kesehatan dengan standar internasional
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className={`hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${service.urgent ? 'border-red-200 bg-red-50' : ''}`}>
                <CardHeader className="text-center">
                  <service.icon className={`w-12 h-12 mx-auto mb-4 ${service.urgent ? 'text-red-600' : 'text-medical-600'}`} />
                  <CardTitle className={service.urgent ? 'text-red-700' : ''}>{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                  {service.urgent && (
                    <Badge variant="destructive" className="mt-2">
                      Layanan Darurat
                    </Badge>
                  )}
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full" 
                    variant={service.urgent ? "destructive" : "outline"} 
                    asChild
                  >
                    <Link to={service.link}>
                      Pelajari Lebih Lanjut
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Mengapa Memilih Kami?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Komitmen kami terhadap pelayanan kesehatan terbaik
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-medical-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-16 px-6 bg-red-50 border-t-4 border-red-500">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <Phone className="w-8 h-8 text-red-600 mr-3" />
            <h2 className="text-3xl font-bold text-red-700">Kontak Darurat</h2>
          </div>
          <p className="text-lg mb-6 text-red-600">
            Untuk kondisi darurat medis, hubungi nomor berikut:
          </p>
          <div className="text-4xl font-bold text-red-700 mb-6">
            (021) 555-0199
          </div>
          <Badge variant="destructive" className="text-lg px-6 py-2">
            24 Jam • 7 Hari Seminggu
          </Badge>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-6 bg-medical-gradient text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Siap Memulai Perjalanan Kesehatan Anda?</h2>
          <p className="text-xl mb-8 opacity-90">
            Bergabunglah dengan ribuan pasien yang telah mempercayakan kesehatan mereka kepada kami
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/pendaftaran-online">
                <UserPlus className="w-5 h-5 mr-2" />
                Daftar Sebagai Pasien
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-medical-600" asChild>
              <Link to="/tentang-rumah-sakit">
                <Heart className="w-5 h-5 mr-2" />
                Pelajari Tentang Kami
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
