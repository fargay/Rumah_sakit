
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const SyaratKetentuan = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Syarat & Ketentuan</h1>
      <Card>
        <CardHeader><CardTitle>Ketentuan Penggunaan</CardTitle></CardHeader>
        <CardContent>
          <p>Syarat dan ketentuan penggunaan layanan digital RS Harapan Sehat.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SyaratKetentuan;
