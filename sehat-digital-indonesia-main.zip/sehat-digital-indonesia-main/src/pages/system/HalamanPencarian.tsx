
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

const HalamanPencarian = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Pencarian</h1>
      <Card>
        <CardHeader><CardTitle>Cari Informasi</CardTitle></CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input placeholder="Masukkan kata kunci..." className="flex-1" />
            <Button>
              <Search className="w-4 h-4 mr-2" />
              Cari
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HalamanPencarian;
