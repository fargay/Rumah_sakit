
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Home } from "lucide-react";
import { Link } from "react-router-dom";

const HalamanError = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto text-center">
        <AlertTriangle className="w-24 h-24 text-destructive mx-auto mb-8" />
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Terjadi Kesalahan</h1>
        <p className="text-gray-600 mb-8">Maaf, terjadi kesalahan pada sistem.</p>
        <Button asChild>
          <Link to="/">
            <Home className="w-4 h-4 mr-2" />
            Kembali ke Beranda
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default HalamanError;
