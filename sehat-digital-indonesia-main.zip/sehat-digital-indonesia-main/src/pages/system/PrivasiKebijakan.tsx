
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const PrivasiKebijakan = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Kebijakan Privasi</h1>
      <Card>
        <CardHeader><CardTitle>Perlindungan Data Pribadi</CardTitle></CardHeader>
        <CardContent>
          <p>RS Harapan Sehat berkomitmen melindungi privasi dan keamanan data pribadi pasien sesuai dengan peraturan yang berlaku.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrivasiKebijakan;
