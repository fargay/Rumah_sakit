
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";

const Sitemap = () => {
  const sitemap = [
    {
      kategori: "Halaman Publik",
      links: [
        { nama: "Beranda", url: "/" },
        { nama: "Tentang Rumah Sakit", url: "/tentang-rumah-sakit" },
        { nama: "Daftar Dokter", url: "/daftar-dokter" },
        { nama: "Jadwal Praktik", url: "/jadwal-praktik" },
        { nama: "Layanan Medis", url: "/layanan-medis" },
        { nama: "IGD", url: "/igd" },
        { nama: "Kontak Kami", url: "/kontak-kami" }
      ]
    },
    {
      kategori: "Layanan Pasien",
      links: [
        { nama: "Pendaftaran Online", url: "/pendaftaran-online" },
        { nama: "Login Pasien", url: "/login-pasien" },
        { nama: "Konsultasi Online", url: "/konsultasi-online" },
        { nama: "Reservasi Ruang", url: "/reservasi-ruang" }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Sitemap</h1>
      <div className="grid gap-6 md:grid-cols-2">
        {sitemap.map((section, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle>{section.kategori}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <Link
                    key={linkIndex}
                    to={link.url}
                    className="block text-medical-600 hover:underline"
                  >
                    {link.nama}
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Sitemap;
