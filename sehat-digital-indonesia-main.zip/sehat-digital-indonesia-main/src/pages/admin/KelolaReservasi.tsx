
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const KelolaReservasi = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Kelola Reservasi</h1>
      <Card>
        <CardHeader><CardTitle>Reservasi Kamar</CardTitle></CardHeader>
        <CardContent><p>Kelola reservasi kamar rawat inap.</p></CardContent>
      </Card>
    </div>
  );
};

export default KelolaReservasi;
