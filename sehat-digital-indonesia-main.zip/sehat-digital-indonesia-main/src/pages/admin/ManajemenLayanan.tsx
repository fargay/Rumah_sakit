
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ManajemenLayanan = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Manajemen Layanan</h1>
      <Card>
        <CardHeader><CardTitle>Kelola Layanan</CardTitle></CardHeader>
        <CardContent><p>Kelola informasi layanan medis dan non-medis.</p></CardContent>
      </Card>
    </div>
  );
};

export default ManajemenLayanan;
