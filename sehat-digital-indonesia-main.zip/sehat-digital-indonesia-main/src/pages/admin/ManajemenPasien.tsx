
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ManajemenPasien = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Manajemen Pasien</h1>
      <Card>
        <CardHeader><CardTitle>Data Pasien</CardTitle></CardHeader>
        <CardContent><p>Kelola data dan riwayat pasien.</p></CardContent>
      </Card>
    </div>
  );
};

export default ManajemenPasien;
