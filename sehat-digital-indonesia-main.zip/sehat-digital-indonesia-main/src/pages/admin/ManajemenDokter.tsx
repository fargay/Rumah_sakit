
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserPlus, Edit, Trash2 } from "lucide-react";

const ManajemenDokter = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-medical-800">Manajemen Dokter</h1>
        <Button><UserPlus className="w-4 h-4 mr-2" />Tambah Dokter</Button>
      </div>
      <Card>
        <CardHeader><CardTitle>Daftar Dokter</CardTitle></CardHeader>
        <CardContent>
          <p>Kelola data dokter dan jadwal praktik.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ManajemenDokter;
