
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, Eye, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const GaleriFoto = () => {
  const kategoriFoto = [
    {
      kategori: "Fasilitas Medis",
      photos: [
        { title: "Ruang ICU Modern", description: "Intensive Care Unit dengan teknologi terdepan" },
        { title: "Ruang Operasi", description: "8 kamar operasi dengan standar internasional" },
        { title: "Laboratorium", description: "Lab klinik dengan peralatan canggih" },
        { title: "Radiologi", description: "CT Scan dan MRI terbaru" }
      ]
    },
    {
      kategori: "Ruang Rawat Inap",
      photos: [
        { title: "Kamar VIP", description: "Kamar rawat inap premium dengan fasilitas lengkap" },
        { title: "Kamar Kelas 1", description: "Ruang perawatan single bed yang nyaman" },
        { title: "Kamar Anak", description: "Ruang perawatan khusus anak dengan dekorasi menarik" },
        { title: "Nurse Station", description: "Pos perawat 24 jam di setiap lantai" }
      ]
    },
    {
      kategori: "Area Publik",
      photos: [
        { title: "Lobby Utama", description: "Area penerimaan yang luas dan nyaman" },
        { title: "Kafeteria", description: "Tempat makan dengan menu sehat dan bergizi" },
        { title: "Taman Rumah Sakit", description: "Area hijau untuk relaksasi pasien dan keluarga" },
        { title: "Tempat Parkir", description: "Area parkir luas dengan kapasitas 300 kendaraan" }
      ]
    },
    {
      kategori: "Kegiatan Rumah Sakit",
      photos: [
        { title: "Seminar Kesehatan", description: "Edukasi kesehatan untuk masyarakat" },
        { title: "Bakti Sosial", description: "Pelayanan kesehatan gratis untuk masyarakat" },
        { title: "Training Medis", description: "Pelatihan berkelanjutan untuk tenaga medis" },
        { title: "Akreditasi", description: "Proses akreditasi KARS Paripurna" }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Galeri Foto</h1>
        <p className="text-lg text-gray-600">
          Dokumentasi visual fasilitas dan kegiatan RS Harapan Sehat
        </p>
      </div>

      <div className="flex gap-4 mb-8 flex-wrap">
        <Badge variant="default" className="bg-medical-500">Semua Kategori</Badge>
        <Badge variant="outline">Fasilitas Medis</Badge>
        <Badge variant="outline">Ruang Rawat Inap</Badge>
        <Badge variant="outline">Area Publik</Badge>
        <Badge variant="outline">Kegiatan</Badge>
      </div>

      <div className="space-y-12">
        {kategoriFoto.map((kategori, index) => (
          <div key={index}>
            <h2 className="text-2xl font-bold text-medical-800 mb-6 flex items-center gap-2">
              <Camera className="w-6 h-6" />
              {kategori.kategori}
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {kategori.photos.map((photo, photoIndex) => (
                <Card key={photoIndex} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-gradient-to-br from-medical-100 to-hospital-100 flex items-center justify-center">
                    <Camera className="w-12 h-12 text-medical-400" />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-2">{photo.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{photo.description}</p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <Eye className="w-3 h-3 mr-1" />
                        Lihat
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Download className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>

      <Card className="mt-12 bg-medical-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <Camera className="w-12 h-12 text-medical-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Lebih Banyak Foto
            </h3>
            <p className="text-gray-600 mb-4">
              Kunjungi album lengkap kami untuk melihat lebih banyak dokumentasi
            </p>
            <div className="flex gap-4 justify-center">
              <Badge variant="outline" className="border-medical-300 text-medical-700">
                500+ Foto Tersedia
              </Badge>
              <Badge variant="outline" className="border-hospital-300 text-hospital-700">
                Update Berkala
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GaleriFoto;
