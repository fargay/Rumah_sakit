
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, CreditCard, FileText, Users, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";

const InformasiRawatJalan = () => {
  const prosedur = [
    {
      step: 1,
      title: "Pendaftaran",
      description: "Daftar di loket pendaftaran atau online",
      detail: "Bawa KTP, kartu BPJS/asuransi, dan surat rujukan jika ada"
    },
    {
      step: 2,
      title: "Verifikasi Data",
      description: "Petugas akan memverifikasi data dan dokumen",
      detail: "Pastikan semua dokumen lengkap dan valid"
    },
    {
      step: 3,
      title: "Pembayaran",
      description: "Lakukan pembayaran administrasi",
      detail: "Terima bukti pembayaran dan nomor antrian"
    },
    {
      step: 4,
      title: "Tunggu Panggilan",
      description: "Menunggu dipanggil di ruang tunggu poli",
      detail: "Pantau layar nomor antrian dan dengarkan pengumuman"
    },
    {
      step: 5,
      title: "Konsultasi Dokter",
      description: "Konsultasi dengan dokter spesialis",
      detail: "Sampaikan keluhan dan ikuti saran dokter"
    },
    {
      step: 6,
      title: "Resep & Kontrol",
      description: "Ambil resep obat dan jadwal kontrol",
      detail: "Tebus obat di apotek dan catat jadwal kontrol berikutnya"
    }
  ];

  const jamOperasional = [
    { hari: "Senin - Jumat", waktu: "08:00 - 20:00 WIB" },
    { hari: "Sabtu", waktu: "08:00 - 14:00 WIB" },
    { hari: "Minggu", waktu: "08:00 - 12:00 WIB (Darurat)" }
  ];

  const tarif = [
    { layanan: "Konsultasi Dokter Umum", harga: "Rp 150.000" },
    { layanan: "Konsultasi Dokter Spesialis", harga: "Rp 300.000" },
    { layanan: "Konsultasi Sub Spesialis", harga: "Rp 450.000" },
    { layanan: "Administrasi Pendaftaran", harga: "Rp 25.000" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Informasi Rawat Jalan</h1>
        <p className="text-lg text-gray-600">
          Panduan lengkap pelayanan rawat jalan di RS Harapan Sehat
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-6 h-6" />
              Prosedur Rawat Jalan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {prosedur.map((item, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-medical-500 text-white rounded-full flex items-center justify-center font-bold">
                      {item.step}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">{item.title}</h3>
                    <p className="text-gray-600 mb-2">{item.description}</p>
                    <p className="text-sm text-gray-500">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Jam Operasional
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {jamOperasional.map((jadwal, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-medical-50 rounded-lg">
                    <span className="font-medium text-gray-800">{jadwal.hari}</span>
                    <span className="text-medical-700">{jadwal.waktu}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Tarif Layanan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tarif.map((item, index) => (
                  <div key={index} className="flex justify-between items-center p-3 border-b border-gray-100 last:border-b-0">
                    <span className="text-sm text-gray-700">{item.layanan}</span>
                    <span className="font-semibold text-medical-700">{item.harga}</span>
                  </div>
                ))}
              </div>
              <Badge variant="secondary" className="w-full justify-center mt-3 bg-hospital-100 text-hospital-800">
                *Tarif dapat berubah sewaktu-waktu
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Lokasi Poli
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Poli Umum</span>
                <Badge variant="outline">Lantai 1</Badge>
              </div>
              <div className="flex justify-between">
                <span>Poli Anak</span>
                <Badge variant="outline">Lantai 1</Badge>
              </div>
              <div className="flex justify-between">
                <span>Poli Dalam</span>
                <Badge variant="outline">Lantai 2</Badge>
              </div>
              <div className="flex justify-between">
                <span>Poli Bedah</span>
                <Badge variant="outline">Lantai 2</Badge>
              </div>
              <div className="flex justify-between">
                <span>Poli Kandungan</span>
                <Badge variant="outline">Lantai 3</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Fasilitas Penunjang
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                "Laboratorium Klinik",
                "Radiologi & USG",
                "Farmasi/Apotek",
                "Fisioterapi",
                "Medical Check-up",
                "Hemodialisa"
              ].map((fasilitas, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-medical-500" />
                  <span className="text-gray-700">{fasilitas}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-medical-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Mulai Konsultasi Sekarang
            </h3>
            <p className="text-gray-600 mb-4">
              Daftarkan diri Anda untuk mendapatkan pelayanan terbaik
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/pendaftaran-online">Daftar Online</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/jadwal-praktik">Lihat Jadwal Dokter</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InformasiRawatJalan;
