
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, Clock, Eye, Share2 } from "lucide-react";

const GaleriVideo = () => {
  const videoKategori = [
    {
      kategori: "Profil Rumah Sakit",
      videos: [
        { 
          title: "Profil RS Harapan Sehat 2024", 
          duration: "3:45", 
          views: "2.5K", 
          description: "Overview lengkap fasilitas dan layanan rumah sakit" 
        },
        { 
          title: "Tour Virtual Rumah Sakit", 
          duration: "8:30", 
          views: "5.2K", 
          description: "Tur virtual keliling fasilitas rumah sakit" 
        },
        { 
          title: "Sejarah dan Perkembangan", 
          duration: "5:15", 
          views: "1.8K", 
          description: "Perjalanan 40 tahun RS Harapan Sehat" 
        }
      ]
    },
    {
      kategori: "Edukasi Kesehatan",
      videos: [
        { 
          title: "Tips Hidup Sehat", 
          duration: "4:20", 
          views: "8.7K", 
          description: "Panduan gaya hidup sehat dari dokter ahli" 
        },
        { 
          title: "Pencegahan Diabetes", 
          duration: "6:15", 
          views: "6.3K", 
          description: "Cara mencegah dan mengelola diabetes" 
        },
        { 
          title: "Kesehatan Jantung", 
          duration: "7:45", 
          views: "4.9K", 
          description: "Menjaga kesehatan jantung untuk semua usia" 
        },
        { 
          title: "Nutrisi Anak", 
          duration: "5:30", 
          views: "3.2K", 
          description: "Panduan nutrisi lengkap untuk anak-anak" 
        }
      ]
    },
    {
      kategori: "Testimoni Pasien",
      videos: [
        { 
          title: "Testimoni Operasi Jantung", 
          duration: "3:20", 
          views: "4.1K", 
          description: "Pengalaman pasien operasi jantung sukses" 
        },
        { 
          title: "Pelayanan IGD Terbaik", 
          duration: "2:45", 
          views: "2.8K", 
          description: "Testimoni penanganan darurat yang cepat" 
        },
        { 
          title: "Rawat Inap Nyaman", 
          duration: "4:10", 
          views: "1.9K", 
          description: "Pengalaman rawat inap yang menyenangkan" 
        }
      ]
    },
    {
      kategori: "Prosedur Medis",
      videos: [
        { 
          title: "Prosedur Endoskopi", 
          duration: "6:30", 
          views: "3.5K", 
          description: "Edukasi prosedur endoskopi untuk pasien" 
        },
        { 
          title: "Persiapan Operasi", 
          duration: "5:45", 
          views: "4.2K", 
          description: "Panduan persiapan sebelum operasi" 
        },
        { 
          title: "Hemodialisa", 
          duration: "7:20", 
          views: "2.7K", 
          description: "Proses dan manfaat terapi hemodialisa" 
        }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Galeri Video</h1>
        <p className="text-lg text-gray-600">
          Koleksi video edukasi, testimoni, dan dokumentasi kegiatan rumah sakit
        </p>
      </div>

      <div className="flex gap-4 mb-8 flex-wrap">
        <Badge variant="default" className="bg-medical-500">Semua Video</Badge>
        <Badge variant="outline">Profil RS</Badge>
        <Badge variant="outline">Edukasi Kesehatan</Badge>
        <Badge variant="outline">Testimoni</Badge>
        <Badge variant="outline">Prosedur Medis</Badge>
      </div>

      <div className="space-y-12">
        {videoKategori.map((kategori, index) => (
          <div key={index}>
            <h2 className="text-2xl font-bold text-medical-800 mb-6 flex items-center gap-2">
              <Play className="w-6 h-6" />
              {kategori.kategori}
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {kategori.videos.map((video, videoIndex) => (
                <Card key={videoIndex} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-gradient-to-br from-medical-100 to-hospital-100 flex items-center justify-center relative group cursor-pointer">
                    <Play className="w-16 h-16 text-white bg-medical-600 rounded-full p-4 group-hover:scale-110 transition-transform" />
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {video.duration}
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-2">{video.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{video.description}</p>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Eye className="w-3 h-3" />
                        {video.views} views
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1">
                        <Play className="w-3 h-3 mr-1" />
                        Putar
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-3 mt-12">
        <Card className="bg-medical-50 border-medical-200">
          <CardHeader>
            <CardTitle className="text-center text-medical-800">Video Terbaru</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-2xl font-bold text-medical-700 mb-2">15+</p>
            <p className="text-sm text-gray-600">Video ditambahkan bulan ini</p>
          </CardContent>
        </Card>

        <Card className="bg-hospital-50 border-hospital-200">
          <CardHeader>
            <CardTitle className="text-center text-hospital-800">Total Views</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-2xl font-bold text-hospital-700 mb-2">100K+</p>
            <p className="text-sm text-gray-600">Total penayangan video</p>
          </CardContent>
        </Card>

        <Card className="bg-medical-50 border-medical-200">
          <CardHeader>
            <CardTitle className="text-center text-medical-800">Channel</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-2xl font-bold text-medical-700 mb-2">5K+</p>
            <p className="text-sm text-gray-600">Subscriber YouTube</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-8 bg-gradient-to-r from-medical-50 to-hospital-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <Play className="w-12 h-12 text-medical-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Subscribe Channel YouTube Kami
            </h3>
            <p className="text-gray-600 mb-4">
              Dapatkan video edukasi kesehatan terbaru dan update rumah sakit
            </p>
            <Button className="bg-red-600 hover:bg-red-700">
              <Play className="w-4 h-4 mr-2" />
              Subscribe YouTube
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GaleriVideo;
