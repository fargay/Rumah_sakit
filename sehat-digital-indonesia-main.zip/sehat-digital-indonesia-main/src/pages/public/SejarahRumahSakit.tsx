
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, Building, Users, Award } from "lucide-react";

const SejarahRumahSakit = () => {
  const milestones = [
    { year: "1985", event: "Pendirian RS Harapan Sehat dengan 50 tempat tidur" },
    { year: "1995", event: "Ekspansi fasilitas dan penambahan layanan spesialis" },
    { year: "2005", event: "Akreditasi pertama dan modernisasi peralatan medis" },
    { year: "2015", event: "Sertifikasi ISO dan implementasi sistem digital" },
    { year: "2025", event: "Pengembangan telemedicine dan AI diagnostik" },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Sejarah Rumah Sakit</h1>
        <p className="text-lg text-gray-600">
          Perjalanan panjang RS Harapan Sehat dalam melayani masyarakat Indonesia
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
        <Card>
          <CardHeader className="text-center">
            <CalendarDays className="w-12 h-12 mx-auto text-medical-600 mb-2" />
            <CardTitle className="text-2xl text-medical-800">40+</CardTitle>
            <p className="text-gray-600">Tahun Pengalaman</p>
          </CardHeader>
        </Card>
        
        <Card>
          <CardHeader className="text-center">
            <Building className="w-12 h-12 mx-auto text-hospital-600 mb-2" />
            <CardTitle className="text-2xl text-hospital-800">300+</CardTitle>
            <p className="text-gray-600">Tempat Tidur</p>
          </CardHeader>
        </Card>
        
        <Card>
          <CardHeader className="text-center">
            <Users className="w-12 h-12 mx-auto text-medical-600 mb-2" />
            <CardTitle className="text-2xl text-medical-800">1M+</CardTitle>
            <p className="text-gray-600">Pasien Dilayani</p>
          </CardHeader>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-6 h-6" />
            Tonggak Sejarah
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-start gap-4 p-4 border-l-4 border-medical-500 bg-medical-50">
                <Badge variant="secondary" className="bg-medical-100 text-medical-800">
                  {milestone.year}
                </Badge>
                <p className="text-gray-700">{milestone.event}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SejarahRumahSakit;
