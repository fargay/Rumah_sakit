
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, Eye, BookOpen, Heart, Baby, Brain } from "lucide-react";
import { Link } from "react-router-dom";

const ArtikelKesehatan = () => {
  const artikelTerbaru = [
    {
      judul: "10 Tips Menjaga Kesehatan Jantung",
      penulis: "Dr. Ahmad Suryanto, Sp.JP",
      tanggal: "24 Mei 2025",
      kategori: "Kardiologi",
      excerpt: "Penyakit jantung masih menjadi penyebab kematian tertinggi. Pelajari cara menjaga kesehatan jantung Anda dengan tips praktis ini.",
      views: "2.5K",
      icon: Heart
    },
    {
      judul: "Panduan Lengkap Imunisasi Anak",
      penulis: "Dr. Maya Sari, Sp.A",
      tanggal: "22 Mei 2025", 
      kategori: "Pediatri",
      excerpt: "Jadwal imunisasi lengkap untuk anak dari bayi hingga remaja. Pastikan anak Anda mendapat perlindungan optimal.",
      views: "1.8K",
      icon: Baby
    },
    {
      judul: "Deteksi Dini Stroke: Kenali Gejalanya",
      penulis: "Dr. Indra Kusuma, Sp.S",
      tanggal: "20 Mei 2025",
      kategori: "Neurologi", 
      excerpt: "Stroke dapat dicegah dan ditangani jika dideteksi dini. Kenali gejala-gejala stroke dan cara pencegahannya.",
      views: "3.2K",
      icon: Brain
    }
  ];

  const kategoriArtikel = [
    { nama: "Semua Artikel", count: 150, active: true },
    { nama: "Kardiologi", count: 25 },
    { nama: "Pediatri", count: 30 },
    { nama: "Neurologi", count: 20 },
    { nama: "Kandungan", count: 28 },
    { nama: "Bedah", count: 22 },
    { nama: "Gizi", count: 25 }
  ];

  const artikelPopuler = [
    { judul: "Diabetes: Pencegahan dan Pengelolaan", views: "5.2K" },
    { judul: "Hipertensi pada Usia Muda", views: "4.8K" },
    { judul: "Kesehatan Mental di Era Digital", views: "4.3K" },
    { judul: "Tips Diet Sehat untuk Keluarga", views: "3.9K" },
    { judul: "Olahraga yang Aman untuk Jantung", views: "3.5K" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Artikel Kesehatan</h1>
        <p className="text-lg text-gray-600">
          Informasi kesehatan terpercaya dari tim dokter spesialis RS Harapan Sehat
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-4 mb-8">
        <div className="lg:col-span-3">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-medical-800 mb-4">Artikel Terbaru</h2>
            <div className="space-y-6">
              {artikelTerbaru.map((artikel, index) => {
                const IconComponent = artikel.icon;
                return (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        <div className="flex-shrink-0 w-20 h-20 bg-medical-100 rounded-lg flex items-center justify-center">
                          <IconComponent className="w-8 h-8 text-medical-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="border-medical-300 text-medical-700">
                              {artikel.kategori}
                            </Badge>
                            <div className="flex items-center gap-1 text-sm text-gray-500">
                              <Eye className="w-3 h-3" />
                              {artikel.views}
                            </div>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-800 mb-2 hover:text-medical-700 cursor-pointer">
                            {artikel.judul}
                          </h3>
                          <p className="text-gray-600 mb-3 line-clamp-2">{artikel.excerpt}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                {artikel.penulis}
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {artikel.tanggal}
                              </div>
                            </div>
                            <Button variant="outline" size="sm">
                              Baca Selengkapnya
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Kategori Artikel
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {kategoriArtikel.map((kategori, index) => (
                  <div key={index} className={`flex items-center justify-between p-2 rounded cursor-pointer hover:bg-gray-50 ${
                    kategori.active ? 'bg-medical-50 text-medical-700' : ''
                  }`}>
                    <span className="text-sm">{kategori.nama}</span>
                    <Badge variant="outline" className="text-xs">
                      {kategori.count}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Artikel Populer</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {artikelPopuler.map((artikel, index) => (
                  <div key={index} className="pb-3 border-b border-gray-100 last:border-b-0">
                    <h4 className="text-sm font-medium text-gray-800 mb-1 hover:text-medical-700 cursor-pointer">
                      {artikel.judul}
                    </h4>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Eye className="w-3 h-3" />
                      {artikel.views} views
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-medical-50 border-medical-200">
            <CardContent className="p-6 text-center">
              <BookOpen className="w-8 h-8 text-medical-600 mx-auto mb-3" />
              <h3 className="font-semibold text-medical-800 mb-2">Newsletter</h3>
              <p className="text-sm text-gray-600 mb-3">
                Dapatkan artikel kesehatan terbaru di email Anda
              </p>
              <Button size="sm" className="w-full">
                Subscribe
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-gradient-to-r from-medical-50 to-hospital-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Konsultasi dengan Dokter
            </h3>
            <p className="text-gray-600 mb-4">
              Butuh penjelasan lebih lanjut? Konsultasikan langsung dengan dokter spesialis kami
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/konsultasi-online">Konsultasi Online</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/daftar-dokter">Lihat Dokter</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ArtikelKesehatan;
