
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Stethoscope, 
  Calendar, 
  Clock, 
  Star, 
  MapPin,
  Search,
  Phone,
  GraduationCap,
  Award,
  Heart,
  Brain,
  Eye,
  Bone,
  Baby
} from "lucide-react";

const DaftarDokter = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSpesialisasi, setFilterSpesialisasi] = useState("");

  const dokterData = [
    {
      id: 1,
      nama: "dr. Ahmad Susanto, Sp.PD",
      spesialisasi: "Penyakit Dalam",
      subSpesialisasi: "Gastroenterohepatologi",
      pengalaman: "15 tahun",
      rating: 4.9,
      jumlahReview: 127,
      jadwal: ["Senin", "Rabu", "Jumat"],
      waktu: "08:00 - 14:00",
      lokasi: "Lantai 2, Ruang 201",
      pendidikan: "FK UI, RSCM Jakarta",
      sertifikasi: ["Sp.PD", "FINASIM"],
      foto: "👨‍⚕️",
      icon: Heart,
      biayaKonsultasi: "Rp 350.000",
      bahasa: ["Indonesia", "Inggris"],
      keahlian: ["Hepatitis", "Gastritis", "Diabetes", "Hipertensi"]
    },
    {
      id: 2,
      nama: "dr. Siti Nurhaliza, Sp.A",
      spesialisasi: "Anak",
      subSpesialisasi: "Tumbuh Kembang",
      pengalaman: "12 tahun",
      rating: 4.8,
      jumlahReview: 89,
      jadwal: ["Selasa", "Kamis", "Sabtu"],
      waktu: "09:00 - 15:00",
      lokasi: "Lantai 1, Ruang 105",
      pendidikan: "FK UNPAD, RS Hasan Sadikin",
      sertifikasi: ["Sp.A", "Sertifikat Tumbuh Kembang"],
      foto: "👩‍⚕️",
      icon: Baby,
      biayaKonsultasi: "Rp 300.000",
      bahasa: ["Indonesia"],
      keahlian: ["Imunisasi", "Gangguan Pertumbuhan", "ADHD", "Autisme"]
    },
    {
      id: 3,
      nama: "dr. Budi Santoso, Sp.OG",
      spesialisasi: "Kandungan",
      subSpesialisasi: "Maternal Fetal",
      pengalaman: "18 tahun",
      rating: 4.7,
      jumlahReview: 156,
      jadwal: ["Senin", "Selasa", "Kamis"],
      waktu: "10:00 - 16:00",
      lokasi: "Lantai 3, Ruang 301",
      pendidikan: "FK UGM, RSUP Dr. Sardjito",
      sertifikasi: ["Sp.OG", "Fellowship USG Obstetri"],
      foto: "👨‍⚕️",
      icon: Heart,
      biayaKonsultasi: "Rp 400.000",
      bahasa: ["Indonesia", "Inggris"],
      keahlian: ["Kehamilan Risiko Tinggi", "USG 4D", "Laparoskopi", "IVF"]
    },
    {
      id: 4,
      nama: "dr. Rina Melati, Sp.JP",
      spesialisasi: "Jantung",
      subSpesialisasi: "Kardiologi Intervensi",
      pengalaman: "20 tahun",
      rating: 4.9,
      jumlahReview: 203,
      jadwal: ["Rabu", "Jumat", "Sabtu"],
      waktu: "08:00 - 12:00",
      lokasi: "Lantai 4, Ruang 401",
      pendidikan: "FK UI, National Heart Centre Singapore",
      sertifikasi: ["Sp.JP", "FIHA", "Fellowship Intervensi"],
      foto: "👩‍⚕️",
      icon: Heart,
      biayaKonsultasi: "Rp 500.000",
      bahasa: ["Indonesia", "Inggris", "Mandarin"],
      keahlian: ["Kateterisasi Jantung", "Angioplasti", "Gagal Jantung", "Aritmia"]
    },
    {
      id: 5,
      nama: "dr. Dedi Kurniawan, Sp.M",
      spesialisasi: "Mata",
      subSpesialisasi: "Retina & Vitreous",
      pengalaman: "14 tahun",
      rating: 4.6,
      jumlahReview: 78,
      jadwal: ["Senin", "Rabu", "Jumat"],
      waktu: "13:00 - 17:00",
      lokasi: "Lantai 2, Ruang 205",
      pendidikan: "FK UNAIR, JEC Eye Hospital",
      sertifikasi: ["Sp.M", "Fellowship Retina"],
      foto: "👨‍⚕️",
      icon: Eye,
      biayaKonsultasi: "Rp 375.000",
      bahasa: ["Indonesia", "Inggris"],
      keahlian: ["Operasi Katarak", "Laser Retina", "Glaukoma", "Kornea"]
    },
    {
      id: 6,
      nama: "dr. Maya Sari, Sp.S",
      spesialisasi: "Saraf",
      subSpesialisasi: "Neurovaskular",
      pengalaman: "16 tahun",
      rating: 4.8,
      jumlahReview: 94,
      jadwal: ["Selasa", "Kamis", "Sabtu"],
      waktu: "09:00 - 14:00",
      lokasi: "Lantai 3, Ruang 310",
      pendidikan: "FK UNHAS, RSCM Jakarta",
      sertifikasi: ["Sp.S", "PERDOSSI"],
      foto: "👩‍⚕️",
      icon: Brain,
      biayaKonsultasi: "Rp 425.000",
      bahasa: ["Indonesia"],
      keahlian: ["Stroke", "Epilepsi", "Sakit Kepala", "Parkinson"]
    }
  ];

  const spesialisasiList = [
    "Semua Spesialisasi",
    "Penyakit Dalam",
    "Anak",
    "Kandungan",
    "Jantung",
    "Mata",
    "Saraf",
    "Bedah",
    "Kulit",
    "THT",
    "Jiwa"
  ];

  const filteredDokter = dokterData.filter(dokter => {
    const matchSearch = dokter.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       dokter.spesialisasi.toLowerCase().includes(searchTerm.toLowerCase());
    const matchFilter = filterSpesialisasi === "" || 
                       filterSpesialisasi === "Semua Spesialisasi" || 
                       dokter.spesialisasi === filterSpesialisasi;
    return matchSearch && matchFilter;
  });

  return (
    <div className="min-h-screen py-8 px-6">
      <div className="container mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-medical-gradient text-white">
            <Stethoscope className="w-4 h-4 mr-2" />
            Tim Medis Profesional
          </Badge>
          <h1 className="text-4xl font-bold mb-4">Daftar Dokter Spesialis</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Tim dokter berpengalaman dan tersertifikasi siap memberikan pelayanan kesehatan terbaik untuk Anda dan keluarga
          </p>
        </div>

        {/* Search & Filter */}
        <div className="mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Cari nama dokter atau spesialisasi..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="w-full md:w-64">
                  <Select value={filterSpesialisasi} onValueChange={setFilterSpesialisasi}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter Spesialisasi" />
                    </SelectTrigger>
                    <SelectContent>
                      {spesialisasiList.map((spesialisasi) => (
                        <SelectItem key={spesialisasi} value={spesialisasi}>
                          {spesialisasi}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Doctor Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDokter.map((dokter) => (
            <Card key={dokter.id} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardHeader className="text-center">
                <div className="w-20 h-20 bg-medical-gradient rounded-full flex items-center justify-center mx-auto mb-4 text-4xl">
                  {dokter.foto}
                </div>
                <CardTitle className="text-lg">{dokter.nama}</CardTitle>
                <CardDescription className="space-y-2">
                  <Badge className="bg-hospital-100 text-hospital-800">
                    {dokter.spesialisasi}
                  </Badge>
                  {dokter.subSpesialisasi && (
                    <div className="text-sm text-muted-foreground">
                      {dokter.subSpesialisasi}
                    </div>
                  )}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Rating & Experience */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{dokter.rating}</span>
                    <span className="text-sm text-muted-foreground">({dokter.jumlahReview})</span>
                  </div>
                  <Badge variant="outline">
                    <GraduationCap className="w-3 h-3 mr-1" />
                    {dokter.pengalaman}
                  </Badge>
                </div>

                {/* Schedule */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-medical-600" />
                    <span>{dokter.jadwal.join(", ")}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-medical-600" />
                    <span>{dokter.waktu}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-medical-600" />
                    <span>{dokter.lokasi}</span>
                  </div>
                </div>

                {/* Fee */}
                <div className="bg-hospital-50 p-3 rounded-lg">
                  <div className="text-sm text-muted-foreground">Biaya Konsultasi</div>
                  <div className="font-semibold text-medical-600">{dokter.biayaKonsultasi}</div>
                </div>

                {/* Specialties */}
                <div>
                  <div className="text-sm font-medium mb-2">Keahlian:</div>
                  <div className="flex flex-wrap gap-1">
                    {dokter.keahlian.slice(0, 3).map((keahlian, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {keahlian}
                      </Badge>
                    ))}
                    {dokter.keahlian.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{dokter.keahlian.length - 3} lainnya
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button className="flex-1 bg-medical-gradient" size="sm">
                    <Calendar className="w-4 h-4 mr-2" />
                    Buat Janji
                  </Button>
                  <Button variant="outline" size="sm">
                    <Phone className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredDokter.length === 0 && (
          <div className="text-center py-12">
            <Stethoscope className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Tidak ada dokter ditemukan</h3>
            <p className="text-muted-foreground">
              Coba ubah kata kunci pencarian atau filter spesialisasi
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-12">
          <Card className="bg-medical-gradient text-white">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Butuh Bantuan Memilih Dokter?</h3>
              <p className="mb-6 opacity-90">
                Tim customer service kami siap membantu Anda menemukan dokter yang tepat sesuai kebutuhan
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Button variant="secondary" size="lg">
                  <Phone className="w-5 h-5 mr-2" />
                  Hubungi Customer Service
                </Button>
                <Button variant="outline" size="lg" className="text-white border-white hover:bg-white hover:text-medical-600">
                  <Calendar className="w-5 h-5 mr-2" />
                  Lihat Jadwal Lengkap
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DaftarDokter;
