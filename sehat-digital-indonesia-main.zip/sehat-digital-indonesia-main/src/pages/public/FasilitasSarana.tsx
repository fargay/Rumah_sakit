
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, Stethoscope, Microscope, Camera, Bed, Zap } from "lucide-react";

const FasilitasSarana = () => {
  const fasilitas = [
    {
      kategori: "Instalasi Medis",
      icon: Stethoscope,
      items: [
        { nama: "ICU (Intensive Care Unit)", kapasitas: "20 bed", status: "Beroperasi" },
        { nama: "NICU (Neonatal ICU)", kapasitas: "15 bed", status: "Beroperasi" },
        { nama: "Ruang Operasi", kapasitas: "8 kamar", status: "24 Jam" },
        { nama: "Hemodialisa", kapasitas: "25 mesin", status: "Senin-Sabtu" },
        { nama: "Endoskopi", kapasitas: "3 unit", status: "Senin-Jumat" }
      ]
    },
    {
      kategori: "Laboratorium & Diagnostik",
      icon: Microscope,
      items: [
        { nama: "Laboratorium Klinik", kapasitas: "24 jam", status: "Lengkap" },
        { nama: "CT Scan 64 Slice", kapasitas: "2 unit", status: "24 Jam" },
        { nama: "MRI 1.5 Tesla", kapasitas: "1 unit", status: "Senin-Sabtu" },
        { nama: "USG 4D", kapasitas: "5 unit", status: "Senin-Sabtu" },
        { nama: "Mammografi Digital", kapasitas: "1 unit", status: "Senin-Jumat" }
      ]
    },
    {
      kategori: "Fasilitas Penunjang",
      icon: Building,
      items: [
        { nama: "Farmasi 24 Jam", kapasitas: "2 lokasi", status: "Beroperasi" },
        { nama: "Bank Darah", kapasitas: "PMI", status: "24 Jam" },
        { nama: "Ambulans", kapasitas: "8 unit", status: "Siaga 24 Jam" },
        { nama: "Kafeteria", kapasitas: "200 kursi", status: "06:00-22:00" },
        { nama: "Parkir", kapasitas: "300 slot", status: "24 Jam" }
      ]
    }
  ];

  const teknologiTerbaru = [
    {
      nama: "Robot Bedah Da Vinci",
      deskripsi: "Teknologi bedah minimal invasif terdepan",
      keunggulan: ["Presisi tinggi", "Pemulihan cepat", "Minimal scarring"]
    },
    {
      nama: "AI Diagnostic System",
      deskripsi: "Sistem diagnostik berbasis kecerdasan buatan",
      keunggulan: ["Akurasi tinggi", "Deteksi dini", "Analisis cepat"]
    },
    {
      nama: "Telemedicine Platform",
      deskripsi: "Platform konsultasi online terintegrasi",
      keunggulan: ["Konsultasi jarak jauh", "Rekam medis digital", "Follow-up otomatis"]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Fasilitas & Sarana</h1>
        <p className="text-lg text-gray-600">
          Fasilitas medis modern dengan teknologi terdepan untuk pelayanan optimal
        </p>
      </div>

      <div className="grid gap-8 mb-12">
        {fasilitas.map((kategori, index) => {
          const IconComponent = kategori.icon;
          return (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <IconComponent className="w-6 h-6 text-medical-600" />
                  {kategori.kategori}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {kategori.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                      <h3 className="font-semibold text-gray-800 mb-2">{item.nama}</h3>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-600">{item.kapasitas}</span>
                        <Badge variant="outline" className="text-xs">
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mb-8">
        <h2 className="text-2xl font-bold text-medical-800 mb-6">Teknologi Terdepan</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {teknologiTerbaru.map((tech, index) => (
            <Card key={index} className="border-medical-200 bg-medical-50">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-5 h-5 text-medical-600" />
                  <Badge className="bg-medical-500">Terbaru</Badge>
                </div>
                <CardTitle className="text-lg">{tech.nama}</CardTitle>
                <p className="text-sm text-gray-600">{tech.deskripsi}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {tech.keunggulan.map((keunggulan, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-medical-500 rounded-full"></div>
                      <span className="text-sm text-gray-700">{keunggulan}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4 mb-8">
        {[
          { icon: Bed, title: "300+", subtitle: "Tempat Tidur" },
          { icon: Stethoscope, title: "50+", subtitle: "Dokter Spesialis" },
          { icon: Camera, title: "8", subtitle: "Ruang Operasi" },
          { icon: Microscope, title: "24/7", subtitle: "Lab & Radiologi" }
        ].map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index} className="text-center">
              <CardContent className="p-6">
                <IconComponent className="w-8 h-8 mx-auto text-medical-600 mb-3" />
                <p className="text-2xl font-bold text-medical-800">{stat.title}</p>
                <p className="text-gray-600">{stat.subtitle}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-hospital-50 border-hospital-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-hospital-800 mb-2">
              Ingin Melihat Fasilitas Kami?
            </h3>
            <p className="text-gray-600 mb-4">
              Kunjungi galeri foto dan video untuk melihat fasilitas lengkap rumah sakit
            </p>
            <div className="flex gap-4 justify-center">
              <Badge variant="outline" className="border-hospital-300 text-hospital-700">
                Tour Virtual Tersedia
              </Badge>
              <Badge variant="outline" className="border-medical-300 text-medical-700">
                Akreditasi KARS Paripurna
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FasilitasSarana;
