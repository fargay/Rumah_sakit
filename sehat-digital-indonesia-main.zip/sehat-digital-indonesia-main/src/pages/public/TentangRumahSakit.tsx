
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, Heart, Award, Clock, Shield } from "lucide-react";

const TentangRumahSakit = () => {
  const achievements = [
    {
      title: "Akreditasi KARS",
      description: "Terakreditasi Paripurna dari Komisi Akreditasi Rumah Sakit",
      icon: Award,
      year: "2023"
    },
    {
      title: "ISO 9001:2015",
      description: "Sertifikasi manajemen mutu internasional",
      icon: Shield,
      year: "2022"
    },
    {
      title: "JCI Certified",
      description: "Sertifikasi Joint Commission International",
      icon: Award,
      year: "2024"
    }
  ];

  const facilities = [
    "200 tempat tidur rawat inap",
    "15 kamar operasi modern",
    "ICU dengan 20 bed",
    "NICU dengan 12 inkubator",
    "Unit hemodialisis",
    "Laboratorium terintegrasi",
    "Radiologi & MRI",
    "Farmasi 24 jam"
  ];

  return (
    <div className="min-h-screen py-8 px-6">
      <div className="container mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-medical-gradient text-white">
            Tentang Kami
          </Badge>
          <h1 className="text-4xl font-bold mb-4">RS Sehat Digital Indonesia</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Rumah sakit modern yang berkomitmen memberikan pelayanan kesehatan terbaik dengan mengintegrasikan teknologi digital terdepan dan tenaga medis profesional
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <Card className="h-fit">
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="w-6 h-6 text-medical-600" />
                <CardTitle>Profil Rumah Sakit</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-lg mb-2">Nama Lengkap</h3>
                <p className="text-muted-foreground">Rumah Sakit Sehat Digital Indonesia</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Tahun Berdiri</h3>
                <p className="text-muted-foreground">1998 (26 tahun melayani masyarakat)</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Tipe Rumah Sakit</h3>
                <p className="text-muted-foreground">Rumah Sakit Umum Tipe B</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Status</h3>
                <p className="text-muted-foreground">Swasta - Terakreditasi Paripurna</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Cakupan Layanan</h3>
                <p className="text-muted-foreground">
                  Layanan kesehatan komprehensif mulai dari promotif, preventif, kuratif, hingga rehabilitatif 
                  untuk seluruh anggota keluarga dengan dukungan teknologi digital terintegrasi
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-6 h-6 text-red-500" />
                  <CardTitle>Filosofi Pelayanan</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  "Kesehatan adalah hak setiap manusia. Kami berkomitmen memberikan pelayanan kesehatan yang 
                  berkualitas, terjangkau, dan dapat diakses oleh semua lapisan masyarakat dengan mengutamakan 
                  keselamatan pasien, kepuasan keluarga, dan inovasi teknologi untuk kemajuan dunia kesehatan Indonesia."
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-6 h-6 text-medical-600" />
                  <CardTitle>Tim Medis</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-medical-600">75+</div>
                    <div className="text-sm text-muted-foreground">Dokter Spesialis</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-medical-600">200+</div>
                    <div className="text-sm text-muted-foreground">Perawat</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-medical-600">50+</div>
                    <div className="text-sm text-muted-foreground">Tenaga Kesehatan</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-medical-600">25+</div>
                    <div className="text-sm text-muted-foreground">Tenaga Administratif</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Achievements */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center mb-8">Penghargaan & Sertifikasi</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <achievement.icon className="w-12 h-12 mx-auto text-yellow-500 mb-4" />
                  <CardTitle className="text-lg">{achievement.title}</CardTitle>
                  <Badge variant="secondary">{achievement.year}</Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{achievement.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Facilities */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Fasilitas & Kapasitas</CardTitle>
            <CardDescription className="text-center">
              Fasilitas medis lengkap dengan teknologi terkini
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {facilities.map((facility, index) => (
                <div key={index} className="flex items-center gap-2 p-3 bg-hospital-50 rounded-lg">
                  <div className="w-2 h-2 bg-medical-gradient rounded-full"></div>
                  <span className="text-sm">{facility}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Commitment */}
        <Card className="bg-medical-gradient text-white">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl mb-4">Komitmen Kami</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <Clock className="w-8 h-8 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Pelayanan 24/7</h3>
                <p className="text-sm opacity-90">
                  Siap melayani kebutuhan kesehatan Anda kapan saja
                </p>
              </div>
              <div>
                <Shield className="w-8 h-8 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Keamanan Data</h3>
                <p className="text-sm opacity-90">
                  Perlindungan data pasien dengan sistem keamanan tinggi
                </p>
              </div>
              <div>
                <Heart className="w-8 h-8 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Pelayanan Humanis</h3>
                <p className="text-sm opacity-90">
                  Mengutamakan kenyamanan dan kepuasan pasien
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TentangRumahSakit;
