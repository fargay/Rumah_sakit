
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Mail, MapPin, Clock, MessageSquare, Headphones } from "lucide-react";

const KontakKami = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Kontak Kami</h1>
        <p className="text-lg text-gray-600">
          Hubungi kami untuk informasi, keluhan, atau keadaan darurat
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3 mb-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-6 h-6" />
                Kirim Pesan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="text-sm font-medium mb-2 block">Nama Lengkap</label>
                  <Input placeholder="Masukkan nama lengkap" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Email</label>
                  <Input type="email" placeholder="nama@email.com" />
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="text-sm font-medium mb-2 block">No. Telepon</label>
                  <Input placeholder="08123456789" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Subjek</label>
                  <Input placeholder="Pilih subjek pesan" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Pesan</label>
                <Textarea placeholder="Tulis pesan Anda di sini..." rows={5} />
              </div>
              <Button className="w-full">Kirim Pesan</Button>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-medical-50 border-medical-200">
            <CardHeader>
              <CardTitle className="text-medical-800">Informasi Kontak</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-medical-600" />
                <div>
                  <p className="font-medium">Telepon Utama</p>
                  <p className="text-sm text-gray-600">(021) 123-4567</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-destructive" />
                <div>
                  <p className="font-medium text-destructive">IGD Darurat</p>
                  <p className="text-sm text-gray-600">(021) 123-4568</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium">WhatsApp</p>
                  <p className="text-sm text-gray-600">0812-3456-7890</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-medical-600" />
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-sm text-gray-600">info@harapansehat.co.id</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Jam Operasional
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>IGD</span>
                <span className="font-medium text-destructive">24 Jam</span>
              </div>
              <div className="flex justify-between">
                <span>Rawat Jalan</span>
                <span className="font-medium">08:00 - 20:00</span>
              </div>
              <div className="flex justify-between">
                <span>Laboratorium</span>
                <span className="font-medium">24 Jam</span>
              </div>
              <div className="flex justify-between">
                <span>Farmasi</span>
                <span className="font-medium">24 Jam</span>
              </div>
              <div className="flex justify-between">
                <span>Customer Service</span>
                <span className="font-medium">07:00 - 21:00</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-6 h-6" />
            Alamat & Lokasi
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2">RS Harapan Sehat</h3>
              <p className="text-gray-600 mb-4">
                Jl. Kesehatan Raya No. 123<br />
                Kelurahan Sehat, Kecamatan Bahagia<br />
                Jakarta Selatan 12345<br />
                DKI Jakarta, Indonesia
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-medical-600" />
                  <span className="text-sm">Call Center: (021) 123-4567</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-medical-600" />
                  <span className="text-sm">info@harapansehat.co.id</span>
                </div>
              </div>
            </div>
            <div className="bg-gray-100 rounded-lg p-4 flex items-center justify-center h-64">
              <div className="text-center">
                <MapPin className="w-12 h-12 text-medical-600 mx-auto mb-2" />
                <p className="text-gray-600">Peta Google Maps</p>
                <p className="text-sm text-gray-500">akan ditampilkan di sini</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default KontakKami;
