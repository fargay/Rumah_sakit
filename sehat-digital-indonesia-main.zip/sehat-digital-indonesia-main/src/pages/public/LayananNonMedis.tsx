import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UtensilsCrossed, Car, Wifi, Shield, Coffee, Heart, Baby, Accessibility } from "lucide-react";

const LayananNonMedis = () => {
  const layananNonMedis = [
    {
      kategori: "Fasilitas Umum",
      icon: Wifi,
      layanan: [
        { nama: "WiFi Gratis", deskripsi: "Internet berkecepatan tinggi di seluruh area" },
        { nama: "ATM Center", deskripsi: "ATM berbagai bank tersedia 24 jam" },
        { nama: "Mushola", deskripsi: "Tempat ibadah dengan fasilitas wudhu" },
        { nama: "Taman Bermain", deskripsi: "Area bermain anak yang aman dan nyaman" }
      ]
    },
    {
      kategori: "Layanan Parkir",
      icon: Car,
      layanan: [
        { nama: "Parkir Motor", deskripsi: "Area parkir motor dengan kapasitas 200 unit" },
        { nama: "Parkir Mobil", deskripsi: "Area parkir mobil dengan kapasitas 100 unit" },
        { nama: "Valet Parking", deskripsi: "Layanan parkir khusus untuk pasien VIP" },
        { nama: "Parkir Ambulans", deskripsi: "Area khusus untuk kendaraan darurat" }
      ]
    },
    {
      kategori: "Layanan Makanan",
      icon: UtensilsCrossed,
      layanan: [
        { nama: "Kafeteria", deskripsi: "Berbagai pilihan makanan sehat dan bergizi" },
        { nama: "Catering Pasien", deskripsi: "Menu makanan khusus sesuai diet pasien" },
        { nama: "Food Court", deskripsi: "Beragam tenant makanan dan minuman" },
        { nama: "Room Service", deskripsi: "Layanan antar makanan ke kamar pasien" }
      ]
    },
    {
      kategori: "Keamanan",
      icon: Shield,
      layanan: [
        { nama: "Security 24 Jam", deskripsi: "Petugas keamanan berjaga sepanjang waktu" },
        { nama: "CCTV Monitoring", deskripsi: "Sistem pengawasan di seluruh area" },
        { nama: "Sistem Access Card", deskripsi: "Kontrol akses untuk area tertentu" },
        { nama: "Emergency Response", deskripsi: "Tim tanggap darurat siaga 24 jam" }
      ]
    },
    {
      kategori: "Kenyamanan Pasien",
      icon: Heart,
      layanan: [
        { nama: "AC Central", deskripsi: "Sistem pendingin ruangan yang optimal" },
        { nama: "TV Cable", deskripsi: "Hiburan televisi di setiap kamar" },
        { nama: "Telepon Interkom", deskripsi: "Komunikasi langsung dengan perawat" },
        { nama: "Bed Side Entertainment", deskripsi: "Sistem hiburan terintegrasi" }
      ]
    },
    {
      kategori: "Dukungan Khusus",
      icon: Accessibility,
      layanan: [
        { nama: "Wheelchair Service", deskripsi: "Penyewaan kursi roda untuk pasien" },
        { nama: "Porter Service", deskripsi: "Bantuan transportasi dalam rumah sakit" },
        { nama: "Interpreter", deskripsi: "Penerjemah untuk pasien asing" },
        { nama: "Social Worker", deskripsi: "Konseling dan dukungan psikososial" }
      ]
    }
  ];

  const layananPremium = [
    {
      nama: "VIP Lounge",
      deskripsi: "Ruang tunggu eksklusif dengan fasilitas premium",
      fasilitas: ["Snack & Beverages", "Majalah & Koran", "WiFi Premium", "Personal Assistant"]
    },
    {
      nama: "Executive Check-up",
      deskripsi: "Paket pemeriksaan kesehatan komprehensif untuk eksekutif",
      fasilitas: ["Private Consultation", "Express Service", "Health Report", "Follow-up Care"]
    },
    {
      nama: "Medical Tourism",
      deskripsi: "Paket layanan khusus untuk wisata medis",
      fasilitas: ["Airport Transfer", "Hotel Booking", "City Tour", "Medical Escort"]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Layanan Non-Medis</h1>
        <p className="text-lg text-gray-600">
          Fasilitas pendukung untuk kenyamanan dan kemudahan pasien serta keluarga
        </p>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold text-medical-800 mb-6">Layanan Premium</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {layananPremium.map((item, index) => (
            <Card key={index} className="border-hospital-200 bg-hospital-50">
              <CardHeader>
                <CardTitle className="text-lg text-hospital-800">{item.nama}</CardTitle>
                <p className="text-sm text-gray-600">{item.deskripsi}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {item.fasilitas.map((fasilitas, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <Coffee className="w-4 h-4 text-hospital-600" />
                      <span className="text-sm text-gray-700">{fasilitas}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-medical-800 mb-6">Semua Layanan Non-Medis</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {layananNonMedis.map((kategori, index) => {
            const IconComponent = kategori.icon;
            return (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-lg">
                    <IconComponent className="w-6 h-6 text-medical-600" />
                    {kategori.kategori}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {kategori.layanan.map((layanan, layananIndex) => (
                      <div key={layananIndex} className="border-l-4 border-medical-500 pl-3 py-1">
                        <h4 className="font-semibold text-gray-800">{layanan.nama}</h4>
                        <p className="text-sm text-gray-600">{layanan.deskripsi}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <Card className="mt-8 bg-gradient-to-r from-medical-50 to-hospital-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Informasi Layanan
            </h3>
            <p className="text-gray-600 mb-4">
              Untuk informasi lebih lanjut tentang layanan non-medis, silakan hubungi customer service
            </p>
            <div className="flex gap-2 justify-center flex-wrap">
              <Badge variant="outline" className="border-medical-300 text-medical-700">
                Telepon: (021) 123-4567
              </Badge>
              <Badge variant="outline" className="border-hospital-300 text-hospital-700">
                Email: info@harapansehat.co.id
              </Badge>
              <Badge variant="outline" className="border-medical-300 text-medical-700">
                Telepon: 0812-3456-7890
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LayananNonMedis;
