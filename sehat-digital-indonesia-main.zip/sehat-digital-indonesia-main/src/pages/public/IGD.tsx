
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Phone, Clock, AlertTriangle, Ambulance, Heart, Activity } from "lucide-react";

const IGD = () => {
  const nomorDarurat = [
    { layanan: "IGD RS Harapan Sehat", nomor: "(021) 123-4567" },
    { layanan: "Ambulans", nomor: "(021) 123-4568" },
    { layanan: "WhatsApp IGD", nomor: "0812-3456-7890" }
  ];

  const jenisKasus = [
    {
      kategori: "Kasus Darurat (Red Zone)",
      warna: "destructive",
      contoh: ["Henti jantung", "Stroke akut", "Trauma berat", "Sesak napas berat"],
      waktu: "Ditangani segera (< 5 menit)"
    },
    {
      kategori: "Kasus Urgent (Yellow Zone)", 
      warna: "secondary",
      contoh: ["Nyeri dada", "Demam tinggi", "Muntah darah", "Cedera sedang"],
      waktu: "Ditangani dalam 30 menit"
    },
    {
      kategori: "Kasus Non-Urgent (Green Zone)",
      warna: "outline",
      contoh: ["Demam ringan", "Batuk pilek", "Luka kecil", "Sakit kepala"],
      waktu: "Ditangani dalam 2 jam"
    }
  ];

  const fasilitas = [
    { nama: "Trauma Center", icon: AlertTriangle },
    { nama: "Resusitasi", icon: Heart },
    { nama: "Observasi", icon: Activity },
    { nama: "Triage", icon: Activity },
    { nama: "Ambulans 24 Jam", icon: Ambulance },
    { nama: "ICU Mobile", icon: Heart }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-destructive mb-4">Instalasi Gawat Darurat (IGD)</h1>
        <p className="text-lg text-gray-600">
          Pelayanan gawat darurat 24 jam dengan tim medis berpengalaman
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-6 h-6" />
              Triage - Sistem Prioritas Penanganan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {jenisKasus.map((kasus, index) => (
                <div key={index} className="border-l-4 border-destructive pl-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant={kasus.warna as any}>{kasus.kategori}</Badge>
                    <span className="text-sm text-gray-600">{kasus.waktu}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {kasus.contoh.map((contoh, idx) => (
                      <span key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded">
                        {contoh}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-destructive text-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-6 h-6" />
              Kontak Darurat
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {nomorDarurat.map((kontak, index) => (
                <div key={index} className="text-center p-3 bg-white/10 rounded-lg">
                  <p className="font-semibold mb-1">{kontak.layanan}</p>
                  <p className="text-xl font-bold">{kontak.nomor}</p>
                </div>
              ))}
              <Button variant="secondary" className="w-full">
                <Phone className="w-4 h-4 mr-2" />
                Panggil Sekarang
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Jam Operasional
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center p-6 bg-medical-50 rounded-lg">
              <p className="text-3xl font-bold text-medical-700 mb-2">24 JAM</p>
              <p className="text-gray-600">7 Hari Seminggu</p>
              <p className="text-sm text-gray-500 mt-2">Termasuk hari libur nasional</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fasilitas IGD</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {fasilitas.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                    <IconComponent className="w-4 h-4 text-medical-600" />
                    <span className="text-sm">{item.nama}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Prosedur Saat Datang ke IGD</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[
              { step: 1, title: "Triage", desc: "Penilaian tingkat kegawatan oleh perawat triage" },
              { step: 2, title: "Registrasi", desc: "Pencatatan identitas dan keluhan utama" },
              { step: 3, title: "Penanganan", desc: "Pemeriksaan dan tindakan medis sesuai prioritas" },
              { step: 4, title: "Disposisi", desc: "Pulang, rawat inap, atau rujuk sesuai kondisi" }
            ].map((prosedur, index) => (
              <div key={index} className="text-center p-4 border rounded-lg">
                <div className="w-8 h-8 bg-destructive text-white rounded-full flex items-center justify-center font-bold mb-2 mx-auto">
                  {prosedur.step}
                </div>
                <h3 className="font-semibold mb-1">{prosedur.title}</h3>
                <p className="text-sm text-gray-600">{prosedur.desc}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-destructive/5 border-destructive/20">
        <CardContent className="p-6">
          <div className="text-center">
            <AlertTriangle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h3 className="text-xl font-bold text-destructive mb-2">
              Dalam Kondisi Darurat?
            </h3>
            <p className="text-gray-600 mb-4">
              Jangan ragu untuk segera datang ke IGD atau hubungi nomor darurat kami
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="destructive" size="lg">
                <Phone className="w-4 h-4 mr-2" />
                Hubungi IGD
              </Button>
              <Button variant="outline" size="lg">
                <Ambulance className="w-4 h-4 mr-2" />
                Panggil Ambulans
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default IGD;
