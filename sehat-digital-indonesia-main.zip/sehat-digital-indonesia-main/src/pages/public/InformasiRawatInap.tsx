
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bed, Wifi, Utensils, Tv, Phone, Shield, Clock, CreditCard } from "lucide-react";
import { Link } from "react-router-dom";

const InformasiRawatInap = () => {
  const kelasKamar = [
    {
      kelas: "Kelas VIP",
      harga: "Rp 1.500.000/hari",
      fasilitas: ["Kamar single", "AC individual", "TV LED 42\"", "Sofa bed", "Kulkas mini", "WiFi premium", "Kamar mandi dalam"],
      tersedia: 10
    },
    {
      kelas: "Kelas I",
      harga: "Rp 800.000/hari",
      fasilitas: ["Kamar single", "AC central", "TV LED 32\"", "Lemari pakaian", "WiFi gratis", "Kamar mandi dalam"],
      tersedia: 20
    },
    {
      kelas: "Kelas II",
      harga: "Rp 500.000/hari",
      fasilitas: ["Kamar double", "AC central", "TV LED 24\"", "Lemari bersama", "WiFi gratis", "Kamar mandi dalam"],
      tersedia: 30
    },
    {
      kelas: "Kelas III",
      harga: "Rp 300.000/hari",
      fasilitas: ["Kamar 4 bed", "Kipas angin", "TV bersama", "Loker pribadi", "WiFi gratis", "Kamar mandi bersama"],
      tersedia: 40
    }
  ];

  const prosedurMasuk = [
    "Bawa surat pengantar rawat inap dari dokter",
    "Lengkapi administrasi di bagian admission",
    "Serahkan kartu identitas dan kartu asuransi/BPJS",
    "Pilih kelas kamar sesuai kebutuhan",
    "Lakukan pembayaran deposit atau jaminan",
    "Antar ke kamar oleh petugas porter"
  ];

  const aturanBesuk = [
    { waktu: "Pagi", jam: "10:00 - 12:00 WIB", maksimal: "2 orang" },
    { waktu: "Sore", jam: "16:00 - 20:00 WIB", maksimal: "2 orang" },
    { waktu: "Anak dibawah 12 tahun", jam: "Tidak diperbolehkan", maksimal: "-" },
    { waktu: "ICU/ICCU", jam: "Sesuai jadwal perawat", maksimal: "1 orang" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Informasi Rawat Inap</h1>
        <p className="text-lg text-gray-600">
          Fasilitas dan pelayanan rawat inap dengan kenyamanan terbaik
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-4 mb-8">
        {kelasKamar.map((kamar, index) => (
          <Card key={index} className={`${kamar.kelas === 'Kelas VIP' ? 'border-2 border-medical-500 bg-medical-50' : ''}`}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{kamar.kelas}</CardTitle>
                {kamar.kelas === 'Kelas VIP' && (
                  <Badge className="bg-medical-500">Premium</Badge>
                )}
              </div>
              <p className="text-2xl font-bold text-medical-700">{kamar.harga}</p>
              <Badge variant="outline" className="w-fit">
                <Bed className="w-3 h-3 mr-1" />
                {kamar.tersedia} kamar tersedia
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {kamar.fasilitas.map((fasilitas, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm">
                    <div className="w-1.5 h-1.5 bg-medical-500 rounded-full"></div>
                    <span>{fasilitas}</span>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4" size="sm" asChild>
                <Link to="/reservasi-ruang">Reservasi</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-8 md:grid-cols-2 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Prosedur Masuk Rawat Inap
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {prosedurMasuk.map((prosedur, index) => (
                <div key={index} className="flex gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-medical-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                  <p className="text-sm text-gray-700">{prosedur}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Jadwal Besuk
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {aturanBesuk.map((aturan, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-gray-800">{aturan.waktu}</span>
                    <Badge variant="outline">{aturan.maksimal}</Badge>
                  </div>
                  <span className="text-sm text-gray-600">{aturan.jam}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Utensils className="w-5 h-5" />
              Layanan Makan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>• Sarapan: 07:00 - 08:00</p>
              <p>• Makan Siang: 12:00 - 13:00</p>
              <p>• Makan Malam: 18:00 - 19:00</p>
              <p>• Menu sesuai diet dokter</p>
              <p>• Snack untuk pasien VIP</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Keamanan & Kenyamanan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>• CCTV 24 jam</p>
              <p>• Perawat jaga malam</p>
              <p>• Call button di setiap bed</p>
              <p>• Sistem fire alarm</p>
              <p>• Security berkeliling</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Fasilitas Komunikasi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>• WiFi gratis 24 jam</p>
              <p>• Telepon interkom</p>
              <p>• TV cable/satelit</p>
              <p>• Charging station</p>
              <p>• Hotline ke nurse station</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-hospital-50 border-hospital-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-hospital-800 mb-2">
              Butuh Reservasi Kamar?
            </h3>
            <p className="text-gray-600 mb-4">
              Pesan kamar rawat inap sesuai kebutuhan Anda
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/reservasi-ruang">Reservasi Sekarang</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/kontak-kami">Hubungi Kami</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InformasiRawatInap;
