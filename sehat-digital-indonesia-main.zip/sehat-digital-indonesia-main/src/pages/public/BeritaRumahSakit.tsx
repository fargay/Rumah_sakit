
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, User, Eye, Megaphone, Award, Building } from "lucide-react";

const BeritaRumahSakit = () => {
  const beritaTerbaru = [
    {
      judul: "RS Harapan Sehat Raih Akreditasi KARS Paripurna 2025",
      kategori: "Prestasi",
      tanggal: "24 Mei 2025",
      penulis: "Tim Humas",
      excerpt: "RS Harapan Sehat berhasil mempertahankan akreditasi KARS Paripurna untuk periode 2025-2028, menunjukkan komitmen terhadap kualitas pelayanan.",
      views: "3.2K",
      featured: true,
      icon: Award
    },
    {
      judul: "Launching Unit Stroke Center Terintegrasi",
      kategori: "Layanan Baru",
      tanggal: "20 Mei 2025",
      penulis: "Dr. Indra Kusuma",
      excerpt: "Pembukaan resmi Stroke Center dengan teknologi terdepan untuk penanganan stroke 24 jam dengan golden period optimal.",
      views: "2.8K",
      featured: false,
      icon: Building
    },
    {
      judul: "Program Bakti Sosial Pemeriksaan Kesehatan Gratis",
      kategori: "Pengumuman",
      tanggal: "18 Mei 2025",
      penulis: "Tim CSR",
      excerpt: "RS Harapan Sehat menggelar bakti sosial pemeriksaan kesehatan gratis untuk 1000 warga kurang mampu di 5 kelurahan.",
      views: "1.9K",
      featured: false,
      icon: Megaphone
    }
  ];

  const kategoriBerita = [
    { nama: "Semua Berita", count: 85, active: true },
    { nama: "Pengumuman", count: 25 },
    { nama: "Prestasi", count: 15 },
    { nama: "Layanan Baru", count: 20 },
    { nama: "Kegiatan Sosial", count: 18 },
    { nama: "Edukasi", count: 7 }
  ];

  const pengumumanPenting = [
    {
      judul: "Jadwal Libur Hari Raya Idul Fitri 2025",
      tanggal: "15 Mei 2025",
      urgent: true
    },
    {
      judul: "Update Tarif Layanan Medis Terbaru",
      tanggal: "10 Mei 2025",
      urgent: false
    },
    {
      judul: "Pembukaan Layanan Hemodialisa Malam",
      tanggal: "5 Mei 2025",
      urgent: false
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Berita Rumah Sakit</h1>
        <p className="text-lg text-gray-600">
          Informasi terkini, pengumuman, dan perkembangan RS Harapan Sehat
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-4 mb-8">
        <div className="lg:col-span-3">
          {/* Berita Utama */}
          {beritaTerbaru.filter(berita => berita.featured).map((berita, index) => {
            const IconComponent = berita.icon;
            return (
              <Card key={index} className="mb-8 border-2 border-medical-200 bg-medical-50">
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-medical-500">Berita Utama</Badge>
                    <Badge variant="outline" className="border-medical-300 text-medical-700">
                      {berita.kategori}
                    </Badge>
                  </div>
                  <div className="flex gap-6">
                    <div className="flex-shrink-0 w-24 h-24 bg-medical-200 rounded-lg flex items-center justify-center">
                      <IconComponent className="w-10 h-10 text-medical-600" />
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold text-gray-800 mb-3 hover:text-medical-700 cursor-pointer">
                        {berita.judul}
                      </h2>
                      <p className="text-gray-600 mb-4">{berita.excerpt}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <User className="w-3 h-3" />
                            {berita.penulis}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {berita.tanggal}
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {berita.views}
                          </div>
                        </div>
                        <Button>Baca Selengkapnya</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Berita Lainnya */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-medical-800">Berita Lainnya</h3>
            {beritaTerbaru.filter(berita => !berita.featured).map((berita, index) => {
              const IconComponent = berita.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0 w-16 h-16 bg-hospital-100 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-6 h-6 text-hospital-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="border-hospital-300 text-hospital-700">
                            {berita.kategori}
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Eye className="w-3 h-3" />
                            {berita.views}
                          </div>
                        </div>
                        <h4 className="text-lg font-semibold text-gray-800 mb-2 hover:text-medical-700 cursor-pointer">
                          {berita.judul}
                        </h4>
                        <p className="text-gray-600 mb-3 text-sm">{berita.excerpt}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 text-xs text-gray-500">
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {berita.penulis}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {berita.tanggal}
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            Baca
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Kategori Berita</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {kategoriBerita.map((kategori, index) => (
                  <div key={index} className={`flex items-center justify-between p-2 rounded cursor-pointer hover:bg-gray-50 ${
                    kategori.active ? 'bg-medical-50 text-medical-700' : ''
                  }`}>
                    <span className="text-sm">{kategori.nama}</span>
                    <Badge variant="outline" className="text-xs">
                      {kategori.count}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-800">
                <Megaphone className="w-5 h-5" />
                Pengumuman Penting
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pengumumanPenting.map((pengumuman, index) => (
                  <div key={index} className="p-3 bg-white rounded border-l-4 border-orange-400">
                    {pengumuman.urgent && (
                      <Badge variant="destructive" className="mb-2 text-xs">URGENT</Badge>
                    )}
                    <h4 className="text-sm font-medium text-gray-800 mb-1">
                      {pengumuman.judul}
                    </h4>
                    <p className="text-xs text-gray-500">{pengumuman.tanggal}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-medical-50 border-medical-200">
            <CardContent className="p-6 text-center">
              <Megaphone className="w-8 h-8 text-medical-600 mx-auto mb-3" />
              <h3 className="font-semibold text-medical-800 mb-2">Berlangganan Berita</h3>
              <p className="text-sm text-gray-600 mb-3">
                Dapatkan update berita terbaru via email
              </p>
              <Button size="sm" className="w-full">
                Subscribe
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default BeritaRumahSakit;
