
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Stethoscope, Heart, Brain, Eye, Bone, Baby } from "lucide-react";
import { Link } from "react-router-dom";

const LayananMedis = () => {
  const layanan = [
    {
      kategori: "Pelayanan Spesialis",
      icon: Stethoscope,
      services: [
        "Penyakit Dalam", "Bedah Umum", "Anak", "Obstetri & Ginekologi",
        "Jantung", "Saraf", "Mata", "THT", "Kulit & Kelamin", "Ortopedi"
      ]
    },
    {
      kategori: "Pelayanan Jantung",
      icon: Heart,
      services: [
        "Kateterisasi Jantung", "Echocardiography", "Elektrokardiografi",
        "Treadmill Test", "Holter Monitor", "Konsultasi Kardiologi"
      ]
    },
    {
      kategori: "Pelayanan Neurologi",
      icon: Brain,
      services: [
        "CT Scan Kepala", "MRI Brain", "EEG", "EMG",
        "Konsultasi Stroke", "Rehabilitasi Neurologis"
      ]
    },
    {
      kategori: "Pelayanan Mata",
      icon: Eye,
      services: [
        "Pemeriksaan Refraksi", "Operasi Katarak", "Operasi Glaukoma",
        "Laser Retina", "Konsultasi Mata Anak"
      ]
    },
    {
      kategori: "Pelayanan Ortopedi",
      icon: Bone,
      services: [
        "Operasi Tulang", "Arthroscopy", "Rehabilitasi Medik",
        "Fisioterapi", "Konsultasi Cedera Olahraga"
      ]
    },
    {
      kategori: "Pelayanan Anak & Bayi",
      icon: Baby,
      services: [
        "NICU", "PICU", "Imunisasi", "Tumbuh Kembang",
        "Konsultasi Gizi Anak", "Pemeriksaan Bayi Baru Lahir"
      ]
    }
  ];

  const unggulan = [
    {
      nama: "Pusat Jantung Terpadu",
      deskripsi: "Layanan jantung komprehensif dengan teknologi terkini",
      fasilitas: ["Cath Lab", "ICCU", "Echocardiography 4D"]
    },
    {
      nama: "Stroke Center",
      deskripsi: "Penanganan stroke 24 jam dengan tim multidisiplin",
      fasilitas: ["CT Scan 64 Slice", "MRI 1.5 Tesla", "Neurointervention"]
    },
    {
      nama: "Cancer Center",
      deskripsi: "Pusat kanker terintegrasi dengan pendekatan holistik",
      fasilitas: ["Chemotherapy", "Radioterapi", "Onkologi Bedah"]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Layanan Medis</h1>
        <p className="text-lg text-gray-600">
          Layanan kesehatan komprehensif dengan standar internasional
        </p>
      </div>

      <div className="mb-12">
        <h2 className="text-2xl font-bold text-medical-800 mb-6">Layanan Unggulan</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {unggulan.map((item, index) => (
            <Card key={index} className="border-medical-200">
              <CardHeader>
                <CardTitle className="text-lg text-medical-800">{item.nama}</CardTitle>
                <p className="text-sm text-gray-600">{item.deskripsi}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {item.fasilitas.map((fasilitas, idx) => (
                    <Badge key={idx} variant="outline" className="mr-2 border-medical-300 text-medical-700">
                      {fasilitas}
                    </Badge>
                  ))}
                </div>
                <Button className="w-full mt-4" variant="outline" asChild>
                  <Link to="/pendaftaran-online">Daftar Konsultasi</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-medical-800 mb-6">Semua Layanan Medis</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {layanan.map((kategori, index) => {
            const IconComponent = kategori.icon;
            return (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-lg">
                    <IconComponent className="w-6 h-6 text-medical-600" />
                    {kategori.kategori}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {kategori.services.map((service, serviceIndex) => (
                      <div key={serviceIndex} className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-medical-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">{service}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <Card className="mt-8 bg-medical-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Butuh Konsultasi Medis?
            </h3>
            <p className="text-gray-600 mb-4">
              Tim dokter spesialis kami siap membantu Anda 24 jam
            </p>
            <div className="flex gap-4 justify-center">
              <Button asChild>
                <Link to="/pendaftaran-online">Daftar Online</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/daftar-dokter">Lihat Dokter</Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LayananMedis;
