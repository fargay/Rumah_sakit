
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Calendar, Phone, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

const JadwalPraktik = () => {
  const jadwalDokter = [
    {
      nama: "Dr. Ahmad Suryanto, Sp.B",
      spesialis: "Bedah Umum",
      jadwal: {
        "Senin": "08:00 - 12:00",
        "Rabu": "14:00 - 17:00",
        "Jumat": "08:00 - 12:00"
      },
      ruang: "Poli Bedah Lt. 2"
    },
    {
      nama: "Dr. Siti Nurhaliza, Sp.PD",
      spesialis: "Penyakit Dalam",
      jadwal: {
        "Selasa": "08:00 - 12:00",
        "Kamis": "14:00 - 17:00",
        "Sabtu": "08:00 - 11:00"
      },
      ruang: "Poli Interna Lt. 1"
    },
    {
      nama: "Dr. Maya Sari, Sp.A",
      spesialis: "Anak",
      jadwal: {
        "Senin": "14:00 - 17:00",
        "Rabu": "08:00 - 12:00",
        "Jumat": "14:00 - 17:00"
      },
      ruang: "Poli Anak Lt. 1"
    },
    {
      nama: "Dr. Indra Kusuma, Sp.OG",
      spesialis: "Obstetri & Ginekologi",
      jadwal: {
        "Selasa": "14:00 - 17:00",
        "Kamis": "08:00 - 12:00",
        "Sabtu": "14:00 - 16:00"
      },
      ruang: "Poli Kandungan Lt. 2"
    }
  ];

  const hari = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Jadwal Praktik Dokter</h1>
        <p className="text-lg text-gray-600">
          Jadwal praktik dokter spesialis di RS Harapan Sehat
        </p>
      </div>

      <div className="grid gap-6 mb-8">
        {jadwalDokter.map((dokter, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl text-medical-800">{dokter.nama}</CardTitle>
                  <Badge variant="secondary" className="mt-2 bg-hospital-100 text-hospital-800">
                    {dokter.spesialis}
                  </Badge>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 text-gray-600 mb-1">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{dokter.ruang}</span>
                  </div>
                  <Button size="sm" asChild>
                    <Link to="/pendaftaran-online">
                      Daftar Online
                    </Link>
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                {hari.map((day) => (
                  <div key={day} className={`p-3 rounded-lg border ${
                    dokter.jadwal[day] 
                      ? 'border-medical-200 bg-medical-50' 
                      : 'border-gray-200 bg-gray-50'
                  }`}>
                    <div className="text-sm font-semibold text-gray-800">{day}</div>
                    {dokter.jadwal[day] ? (
                      <div className="flex items-center gap-1 mt-1">
                        <Clock className="w-3 h-3 text-medical-600" />
                        <span className="text-xs text-medical-700">{dokter.jadwal[day]}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-500">Libur</span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Informasi Penting
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-gray-600">• Pendaftaran dibuka 30 menit sebelum jadwal praktik</p>
            <p className="text-sm text-gray-600">• Daftar online untuk menghindari antrian panjang</p>
            <p className="text-sm text-gray-600">• Bawa kartu identitas dan kartu BPJS/asuransi</p>
            <p className="text-sm text-gray-600">• Jadwal dapat berubah sewaktu-waktu</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Kontak Pendaftaran
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="font-semibold">Telepon:</span>
              <span className="text-medical-600">(021) 123-4567</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold">WhatsApp:</span>
              <span className="text-medical-600">0812-3456-7890</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold">Jam Layanan:</span>
              <span>24 Jam</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default JadwalPraktik;
