
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Search, HelpCircle, Phone, MessageSquare } from "lucide-react";
import { useState } from "react";

const FAQ = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const faqKategori = [
    {
      kategori: "Pendaftaran & Administrasi",
      faqs: [
        {
          pertanyaan: "Bagaimana cara mendaftar sebagai pasien baru?",
          jawaban: "Untuk mendaftar sebagai pasien baru, Anda dapat datang langsung ke loket pendaftaran dengan membawa KTP dan kartu BPJS/asuransi, atau mendaftar online melalui website kami di menu 'Pendaftaran Online'."
        },
        {
          pertanyaan: "Apa saja dokumen yang diperlukan untuk pendaftaran?",
          jawaban: "Dokumen yang diperlukan: KTP/identitas diri, kartu BPJS/asuransi kesehatan, surat rujukan (jika ada), dan kartu keluarga untuk pasien anak."
        },
        {
          pertanyaan: "Apakah bisa daftar tanpa BPJS?",
          jawaban: "Ya, Anda tetap bisa berobat tanpa BPJS dengan pembayaran tunai atau menggunakan asuransi swasta lainnya."
        }
      ]
    },
    {
      kategori: "Jadwal & Pelayanan",
      faqs: [
        {
          pertanyaan: "Bagaimana cara melihat jadwal dokter?",
          jawaban: "Jadwal dokter dapat dilihat di website kami pada menu 'Jadwal Praktik', atau hubungi call center di (021) 123-4567."
        },
        {
          pertanyaan: "Apakah IGD buka 24 jam?",
          jawaban: "Ya, IGD RS Harapan Sehat melayani 24 jam setiap hari termasuk hari libur nasional."
        },
        {
          pertanyaan: "Bisakah konsultasi online dengan dokter?",
          jawaban: "Ya, kami menyediakan layanan konsultasi online melalui platform telemedicine. Silakan akses menu 'Konsultasi Online' di website kami."
        }
      ]
    },
    {
      kategori: "Rawat Inap",
      faqs: [
        {
          pertanyaan: "Apa saja kelas kamar yang tersedia?",
          jawaban: "Kami menyediakan kamar VIP, Kelas I, Kelas II, dan Kelas III dengan fasilitas yang berbeda-beda sesuai kebutuhan pasien."
        },
        {
          pertanyaan: "Bagaimana cara reservasi kamar rawat inap?",
          jawaban: "Reservasi kamar dapat dilakukan melalui menu 'Reservasi Ruang' di website, atau hubungi bagian admission di (021) 123-4567 ext. 101."
        },
        {
          pertanyaan: "Apa saja aturan jam besuk?",
          jawaban: "Jam besuk: Pagi 10:00-12:00, Sore 16:00-20:00 dengan maksimal 2 pengunjung. Anak di bawah 12 tahun tidak diperbolehkan masuk area rawat inap."
        }
      ]
    },
    {
      kategori: "Pembayaran & Asuransi",
      faqs: [
        {
          pertanyaan: "Metode pembayaran apa saja yang diterima?",
          jawaban: "Kami menerima pembayaran tunai, debit/kredit card, BPJS, dan berbagai asuransi swasta yang bekerjasama dengan rumah sakit."
        },
        {
          pertanyaan: "Apakah ada cicilan untuk biaya pengobatan?",
          jawaban: "Ya, tersedia program cicilan untuk tindakan medis tertentu. Silakan konsultasi dengan bagian keuangan untuk informasi lebih lanjut."
        },
        {
          pertanyaan: "Bagaimana cara klaim asuransi?",
          jawaban: "Untuk klaim asuransi, silakan hubungi bagian admisi dengan membawa kartu asuransi dan dokumen pendukung lainnya."
        }
      ]
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">FAQ (Pertanyaan yang Sering Diajukan)</h1>
        <p className="text-lg text-gray-600">
          Temukan jawaban untuk pertanyaan yang sering diajukan tentang layanan RS Harapan Sehat
        </p>
      </div>

      <div className="mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input 
                  placeholder="Cari pertanyaan..." 
                  className="pl-10"
                />
              </div>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Cari
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-8 lg:grid-cols-4">
        <div className="lg:col-span-3">
          <div className="space-y-8">
            {faqKategori.map((kategori, kategoriIndex) => (
              <Card key={kategoriIndex}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HelpCircle className="w-6 h-6 text-medical-600" />
                    {kategori.kategori}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {kategori.faqs.map((faq, faqIndex) => {
                      const itemIndex = kategoriIndex * 10 + faqIndex;
                      const isOpen = openItems.includes(itemIndex);
                      
                      return (
                        <Collapsible key={faqIndex}>
                          <CollapsibleTrigger 
                            className="w-full text-left"
                            onClick={() => toggleItem(itemIndex)}
                          >
                            <div className="flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
                              <h3 className="font-medium text-gray-800 pr-4">
                                {faq.pertanyaan}
                              </h3>
                              <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform ${
                                isOpen ? 'rotate-180' : ''
                              }`} />
                            </div>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <div className="p-4 bg-medical-50 border-l-4 border-medical-500 mt-2 rounded-lg">
                              <p className="text-gray-700">{faq.jawaban}</p>
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <Card className="bg-medical-50 border-medical-200">
            <CardHeader>
              <CardTitle className="text-medical-800">Kategori FAQ</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {faqKategori.map((kategori, index) => (
                  <div key={index} className="flex items-center justify-between p-2 hover:bg-medical-100 rounded cursor-pointer">
                    <span className="text-sm">{kategori.kategori}</span>
                    <Badge variant="outline" className="text-xs border-medical-300 text-medical-700">
                      {kategori.faqs.length}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-hospital-50 border-hospital-200">
            <CardHeader>
              <CardTitle className="text-hospital-800">Butuh Bantuan Lain?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <Phone className="w-8 h-8 text-hospital-600 mx-auto mb-3" />
                <h3 className="font-semibold mb-2">Hubungi Call Center</h3>
                <p className="text-sm text-gray-600 mb-3">
                  Tim customer service siap membantu 24 jam
                </p>
                <Button size="sm" className="w-full mb-2">
                  <Phone className="w-4 h-4 mr-2" />
                  (021) 123-4567
                </Button>
                <Button size="sm" variant="outline" className="w-full">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  WhatsApp Chat
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>FAQ Populer</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[
                  "Cara daftar online?",
                  "Jam besuk rawat inap?",
                  "Jadwal dokter hari ini?",
                  "Metode pembayaran?",
                  "Nomor IGD darurat?"
                ].map((pertanyaan, index) => (
                  <div key={index} className="p-2 text-sm hover:bg-gray-50 rounded cursor-pointer">
                    {pertanyaan}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="mt-8 bg-gradient-to-r from-medical-50 to-hospital-50 border-medical-200">
        <CardContent className="p-6">
          <div className="text-center">
            <HelpCircle className="w-12 h-12 text-medical-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-medical-800 mb-2">
              Tidak Menemukan Jawaban?
            </h3>
            <p className="text-gray-600 mb-4">
              Kirim pertanyaan Anda dan tim kami akan membantu memberikan jawaban terbaik
            </p>
            <div className="flex gap-4 justify-center">
              <Button>
                <MessageSquare className="w-4 h-4 mr-2" />
                Kirim Pertanyaan
              </Button>
              <Button variant="outline">
                <Phone className="w-4 h-4 mr-2" />
                Hubungi CS
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FAQ;
