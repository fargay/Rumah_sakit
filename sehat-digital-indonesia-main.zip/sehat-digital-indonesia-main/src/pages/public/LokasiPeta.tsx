
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Car, Bus, Plane, Clock } from "lucide-react";

const LokasiPeta = () => {
  const petunjukArah = [
    {
      transportasi: "Mobil Pribadi",
      icon: Car,
      rute: [
        "Dari Bandara Soekarno-Hatta: Ambil Tol Soetta - Serpong - TB Simatupang",
        "Keluar di Exit Pondok Indah, lurus ke arah Lebak Bulus",
        "Belok kanan di Jl. Kesehatan Raya, RS ada di sebelah kiri"
      ],
      estimasi: "45-60 menit dari bandara"
    },
    {
      transportasi: "Transportasi Umum",
      icon: Bus,
      rute: [
        "Dari Terminal Blok M: Naik TransJakarta koridor 1 ke arah Lebak Bulus",
        "Turun di Halte Lebak Bulus, lanjut naik ojek online atau angkot",
        "Jarak sekitar 2 km dari halte ke rumah sakit"
      ],
      estimasi: "30-45 menit dari Blok M"
    },
    {
      transportasi: "Dari Bandara",
      icon: Plane,
      rute: [
        "Bandara Soekarno-Hatta: Naik kereta Railink ke Stasiun BNI City",
        "Lanjut naik MRT ke Stasiun Lebak Bulus Grab", 
        "Dari stasiun naik ojek online atau taksi (5 menit)"
      ],
      estimasi: "90 menit total perjalanan"
    }
  ];

  const tempatTerdekat = [
    { nama: "Mall Pondok Indah", jarak: "2.5 km", waktu: "5 menit" },
    { nama: "Universitas Indonesia", jarak: "3.2 km", waktu: "8 menit" },
    { nama: "Stasiun MRT Lebak Bulus", jarak: "1.8 km", waktu: "4 menit" },
    { nama: "Terminal Lebak Bulus", jarak: "2.1 km", waktu: "6 menit" },
    { nama: "Tol TB Simatupang", jarak: "1.5 km", waktu: "3 menit" }
  ];

  const layananTransportasi = [
    {
      nama: "Ambulans Rumah Sakit",
      tersedia: "24 Jam",
      nomor: "(021) 123-4568",
      catatan: "Layanan gratis untuk pasien rujukan"
    },
    {
      nama: "Shuttle Bus",
      tersedia: "06:00 - 22:00",
      nomor: "(021) 123-4567",
      catatan: "Shuttle ke stasiun MRT setiap 30 menit"
    },
    {
      nama: "Valet Parking",
      tersedia: "24 Jam",
      nomor: "Ext. 1234",
      catatan: "Khusus pasien VIP dan keluarga"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Lokasi & Peta</h1>
        <p className="text-lg text-gray-600">
          Panduan lengkap lokasi dan petunjuk arah menuju RS Harapan Sehat
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3 mb-8">
        <div className="lg:col-span-2">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-6 h-6" />
                Peta Lokasi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-100 rounded-lg p-8 flex items-center justify-center h-96">
                <div className="text-center">
                  <MapPin className="w-16 h-16 text-medical-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Peta Interaktif</h3>
                  <p className="text-gray-600 mb-4">Google Maps akan ditampilkan di sini</p>
                  <Button className="mr-2">
                    <Navigation className="w-4 h-4 mr-2" />
                    Buka di Google Maps
                  </Button>
                  <Button variant="outline">
                    <Navigation className="w-4 h-4 mr-2" />
                    Navigasi
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Petunjuk Arah</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {petunjukArah.map((petunjuk, index) => {
                  const IconComponent = petunjuk.icon;
                  return (
                    <div key={index} className="border-l-4 border-medical-500 pl-4">
                      <div className="flex items-center gap-2 mb-2">
                        <IconComponent className="w-5 h-5 text-medical-600" />
                        <h3 className="font-semibold text-gray-800">{petunjuk.transportasi}</h3>
                        <Badge variant="outline" className="border-medical-300 text-medical-700">
                          <Clock className="w-3 h-3 mr-1" />
                          {petunjuk.estimasi}
                        </Badge>
                      </div>
                      <div className="space-y-1">
                        {petunjuk.rute.map((langkah, langkahIndex) => (
                          <p key={langkahIndex} className="text-sm text-gray-600">
                            {langkahIndex + 1}. {langkah}
                          </p>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-medical-50 border-medical-200">
            <CardHeader>
              <CardTitle className="text-medical-800">Alamat Lengkap</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold">RS Harapan Sehat</h3>
                  <p className="text-sm text-gray-600">
                    Jl. Kesehatan Raya No. 123<br />
                    Kelurahan Sehat, Kecamatan Bahagia<br />
                    Jakarta Selatan 12345<br />
                    DKI Jakarta, Indonesia
                  </p>
                </div>
                <div className="pt-3 border-t">
                  <p className="text-sm text-gray-600">
                    <strong>Koordinat GPS:</strong><br />
                    -6.2615, 106.8106
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tempat Terdekat</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tempatTerdekat.map((tempat, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <div>
                      <p className="font-medium text-sm">{tempat.nama}</p>
                      <p className="text-xs text-gray-500">{tempat.jarak}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {tempat.waktu}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Layanan Transportasi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {layananTransportasi.map((layanan, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-medium text-sm">{layanan.nama}</h4>
                      <Badge variant="outline" className="text-xs">
                        {layanan.tersedia}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mb-1">📞 {layanan.nomor}</p>
                    <p className="text-xs text-gray-500">{layanan.catatan}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-hospital-50 border-hospital-200">
        <CardContent className="p-6">
          <div className="text-center">
            <Navigation className="w-12 h-12 text-hospital-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-hospital-800 mb-2">
              Butuh Bantuan Arah?
            </h3>
            <p className="text-gray-600 mb-4">
              Hubungi customer service kami untuk panduan arah yang lebih detail
            </p>
            <div className="flex gap-4 justify-center">
              <Button variant="outline">
                <Navigation className="w-4 h-4 mr-2" />
                Call Center: (021) 123-4567
              </Button>
              <Button>
                <MapPin className="w-4 h-4 mr-2" />
                WhatsApp: 0812-3456-7890
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LokasiPeta;
