
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, Building2, Stethoscope } from "lucide-react";

const StrukturOrganisasi = () => {
  const struktur = [
    {
      tingkat: "Dewan Direksi",
      jabatan: [
        { nama: "Dr. Ahmad Suryanto, Sp.B", posisi: "Direktur Utama" },
        { nama: "Dr. Siti Nurhaliza, M.Kes", posisi: "Direktur Medis" },
        { nama: "Drs. Bambang Wijaya, M.M", posisi: "Direktur Keuangan" },
      ],
      icon: Building2,
      color: "medical"
    },
    {
      tingkat: "Kepala Instalasi",
      jabatan: [
        { nama: "Dr. Indra Kusuma, Sp.PD", posisi: "Ka. Instalasi Rawat Jalan" },
        { nama: "Dr. Maya Sari, Sp.A", posisi: "Ka. Instalasi Rawat Inap" },
        { nama: "Dr. Rudi Hartono, Sp.EM", posisi: "Ka. Instalasi Gawat Darurat" },
        { nama: "Dr. Lina Permata, Sp.PK", posisi: "Ka. Instalasi Laboratorium" },
      ],
      icon: UserCheck,
      color: "hospital"
    },
    {
      tingkat: "Manajer Unit",
      jabatan: [
        { nama: "Ns. Andi Prasetyo, S.Kep", posisi: "Manajer Keperawatan" },
        { nama: "Apt. Dewi Kartika, S.Farm", posisi: "Manajer Farmasi" },
        { nama: "dr. Hendra Wijaya", posisi: "Manajer Radiologi" },
        { nama: "Drs. Agus Setiawan", posisi: "Manajer SDM" },
      ],
      icon: Users,
      color: "medical"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Struktur Organisasi</h1>
        <p className="text-lg text-gray-600">
          Hierarki kepemimpinan dan manajemen RS Harapan Sehat
        </p>
      </div>

      <div className="space-y-8">
        {struktur.map((level, index) => {
          const IconComponent = level.icon;
          return (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <IconComponent className="w-6 h-6" />
                  {level.tingkat}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {level.jabatan.map((person, personIndex) => (
                    <div key={personIndex} className={`p-4 rounded-lg border-l-4 ${
                      level.color === 'medical' 
                        ? 'border-medical-500 bg-medical-50' 
                        : 'border-hospital-500 bg-hospital-50'
                    }`}>
                      <h3 className="font-semibold text-gray-800">{person.nama}</h3>
                      <Badge variant="outline" className={`mt-2 ${
                        level.color === 'medical' 
                          ? 'border-medical-300 text-medical-700' 
                          : 'border-hospital-300 text-hospital-700'
                      }`}>
                        {person.posisi}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Stethoscope className="w-6 h-6" />
            Komite Medis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="font-semibold mb-2">Komite Medis</h3>
              <p className="text-gray-600">Bertanggung jawab atas kualitas pelayanan medis dan kredensial dokter</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Komite Keperawatan</h3>
              <p className="text-gray-600">Mengawasi standar praktek keperawatan dan pengembangan SDM</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StrukturOrganisasi;
