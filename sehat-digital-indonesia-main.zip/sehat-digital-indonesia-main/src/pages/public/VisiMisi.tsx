
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, Target, Star, Users, Heart, Shield, Clock, Award } from "lucide-react";

const VisiMisi = () => {
  const visiPoin = [
    "Menjadi rumah sakit digital terdepan di Indonesia",
    "Memberikan layanan kesehatan berkualitas internasional",
    "Mengintegrasikan teknologi modern dalam setiap layanan",
    "Menciptakan pengalaman pasien yang luar biasa"
  ];

  const misiPoin = [
    {
      icon: Heart,
      title: "Pelayanan Berkualitas",
      description: "Memberikan pelayanan kesehatan yang berkualitas tinggi, aman, dan terjangkau untuk semua lapisan masyarakat"
    },
    {
      icon: Users,
      title: "Tim Profesional",
      description: "Mengembangkan dan mempertahankan tim medis yang kompeten, profesional, dan berdedikasi tinggi"
    },
    {
      icon: Shield,
      title: "Teknologi Terdepan",
      description: "Menggunakan teknologi medis terkini dan sistem informasi terintegrasi untuk mendukung pelayanan optimal"
    },
    {
      icon: Star,
      title: "Inovasi Berkelanjutan",
      description: "Melakukan inovasi berkelanjutan dalam metode pengobatan dan sistem pelayanan kesehatan"
    },
    {
      icon: Clock,
      title: "Aksesibilitas 24/7",
      description: "Menyediakan akses layanan kesehatan yang mudah dan cepat selama 24 jam setiap hari"
    },
    {
      icon: Award,
      title: "Standar Internasional",
      description: "Mempertahankan standar pelayanan internasional dan akreditasi terbaik dalam industri kesehatan"
    }
  ];

  const nilaiUtama = [
    {
      title: "CARING",
      subtitle: "Peduli",
      description: "Memberikan perhatian penuh dan empati terhadap setiap pasien dengan pendekatan yang humanis"
    },
    {
      title: "EXCELLENCE",
      subtitle: "Keunggulan",
      description: "Berkomitmen mencapai standar tertinggi dalam setiap aspek pelayanan kesehatan"
    },
    {
      title: "INTEGRITY",
      subtitle: "Integritas",
      description: "Menjunjung tinggi kejujuran, transparansi, dan etika dalam setiap tindakan medis"
    },
    {
      title: "INNOVATION",
      subtitle: "Inovasi",
      description: "Terus berinovasi untuk memberikan solusi kesehatan terbaik dengan teknologi terdepan"
    },
    {
      title: "TEAMWORK",
      subtitle: "Kerjasama",
      description: "Membangun sinergi tim yang solid untuk memberikan pelayanan terpadu dan komprehensif"
    }
  ];

  return (
    <div className="min-h-screen py-8 px-6">
      <div className="container mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-medical-gradient text-white">
            Visi & Misi
          </Badge>
          <h1 className="text-4xl font-bold mb-4">Visi, Misi & Nilai</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Landasan filosofis dan arah strategis RS Sehat Digital Indonesia dalam memberikan pelayanan kesehatan terbaik
          </p>
        </div>

        {/* Visi */}
        <div className="mb-12">
          <Card className="bg-medical-gradient text-white">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Eye className="w-8 h-8" />
                <CardTitle className="text-3xl">VISI</CardTitle>
              </div>
              <CardDescription className="text-white/90 text-lg">
                Pandangan masa depan RS Sehat Digital Indonesia
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold mb-6 leading-relaxed">
                  "Menjadi Rumah Sakit Digital Terdepan di Indonesia yang Memberikan Pelayanan Kesehatan Berkualitas Internasional dengan Teknologi Modern dan Pelayanan Humanis"
                </h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {visiPoin.map((poin, index) => (
                  <div key={index} className="flex items-start gap-3 bg-white/10 p-4 rounded-lg backdrop-blur-sm">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-medical-600 font-bold text-sm">{index + 1}</span>
                    </div>
                    <p className="text-white/95">{poin}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Misi */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Target className="w-8 h-8 text-medical-600" />
              <h2 className="text-3xl font-bold">MISI</h2>
            </div>
            <p className="text-muted-foreground text-lg">
              Langkah strategis untuk mewujudkan visi kami
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {misiPoin.map((misi, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-medical-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                    <misi.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{misi.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center">{misi.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Nilai Utama */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">NILAI-NILAI UTAMA</h2>
            <p className="text-muted-foreground text-lg">
              Prinsip fundamental yang membimbing setiap tindakan kami
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {nilaiUtama.map((nilai, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-hospital-100 rounded-lg flex items-center justify-center">
                      <span className="text-2xl font-bold text-medical-600">{nilai.title[0]}</span>
                    </div>
                    <div>
                      <CardTitle className="text-xl text-medical-600">{nilai.title}</CardTitle>
                      <CardDescription className="text-lg font-medium">{nilai.subtitle}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{nilai.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <Card className="bg-hospital-50 border-medical-200">
          <CardContent className="text-center py-12">
            <h3 className="text-2xl font-bold mb-4">Bergabunglah dalam Misi Kami</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Bersama-sama kita wujudkan visi rumah sakit digital terdepan yang memberikan pelayanan kesehatan terbaik untuk masyarakat Indonesia
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Badge className="bg-medical-gradient text-white px-6 py-2 text-sm">
                🏥 Rumah Sakit Terpercaya
              </Badge>
              <Badge variant="outline" className="border-medical-200 text-medical-700 px-6 py-2 text-sm">
                ⭐ Akreditasi Paripurna
              </Badge>
              <Badge variant="secondary" className="px-6 py-2 text-sm">
                🔒 ISO Certified
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default VisiMisi;
