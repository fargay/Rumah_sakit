
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Lock, User } from "lucide-react";

const LoginPegawai = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-medical-800 mb-2">Login Pegawai</h1>
          <p className="text-gray-600">Portal pegawai rumah sakit</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 justify-center">
              <Users className="w-6 h-6" />
              Portal Pegawai
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">ID Pegawai</label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input placeholder="ID Pegawai" className="pl-10" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input type="password" placeholder="Password" className="pl-10" />
              </div>
            </div>
            <Button className="w-full">
              <Users className="w-4 h-4 mr-2" />
              Masuk
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LoginPegawai;
