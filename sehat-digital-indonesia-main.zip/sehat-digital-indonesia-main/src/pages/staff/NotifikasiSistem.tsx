
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const NotifikasiSistem = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Notifikasi Sistem</h1>
      <Card>
        <CardHeader><CardTitle>Pemberitahuan</CardTitle></CardHeader>
        <CardContent><p>Notifikasi penting untuk staf rumah sakit.</p></CardContent>
      </Card>
    </div>
  );
};

export default NotifikasiSistem;
