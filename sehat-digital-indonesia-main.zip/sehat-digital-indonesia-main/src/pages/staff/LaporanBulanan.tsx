
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const LaporanBulanan = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-medical-800 mb-8">Laporan Bulanan</h1>
      <Card>
        <CardHeader><CardTitle>Laporan Operasional</CardTitle></CardHeader>
        <CardContent><p>Lihat laporan bulanan rumah sakit.</p></CardContent>
      </Card>
    </div>
  );
};

export default LaporanBulanan;
