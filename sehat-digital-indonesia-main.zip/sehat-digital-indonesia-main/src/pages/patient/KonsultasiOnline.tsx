
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Video, MessageSquare, Phone, Calendar } from "lucide-react";

const KonsultasiOnline = () => {
  const dokterOnline = [
    { nama: "Dr. Siti Nurhaliza, Sp.PD", spesialis: "Penyakit Dalam", status: "Online", rating: "4.8" },
    { nama: "Dr. Ahmad Suryanto, Sp.B", spesialis: "Bedah", status: "Busy", rating: "4.9" },
    { nama: "Dr. Maya Sari, Sp.A", spesialis: "Anak", status: "Online", rating: "4.7" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Konsultasi Online</h1>
        <p className="text-lg text-gray-600">
          Konsultasi dengan dokter secara online melalui video call atau chat
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {dokterOnline.map((dokter, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="text-lg">{dokter.nama}</CardTitle>
              <p className="text-gray-600">{dokter.spesialis}</p>
              <div className="flex items-center gap-2">
                <Badge variant={dokter.status === 'Online' ? 'default' : 'secondary'}>
                  {dokter.status}
                </Badge>
                <span className="text-sm">⭐ {dokter.rating}</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full" disabled={dokter.status !== 'Online'}>
                <Video className="w-4 h-4 mr-2" />
                Video Call
              </Button>
              <Button variant="outline" className="w-full">
                <MessageSquare className="w-4 h-4 mr-2" />
                Chat
              </Button>
              <Button variant="outline" className="w-full">
                <Calendar className="w-4 h-4 mr-2" />
                Jadwalkan
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default KonsultasiOnline;
