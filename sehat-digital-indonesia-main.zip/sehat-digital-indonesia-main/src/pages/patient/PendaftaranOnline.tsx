
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { UserPlus, CheckCircle, AlertCircle, FileText, User, Phone, Mail, MapPin, Calendar, Heart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PendaftaranOnline = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    namaLengkap: "",
    nik: "",
    tanggalLahir: "",
    jenisKelamin: "",
    alamat: "",
    nomorTelepon: "",
    email: "",
    pekerjaan: "",
    pendidikan: "",
    agama: "",
    statusPernikahan: "",
    namaKeluarga: "",
    hubunganKeluarga: "",
    teleponKeluarga: "",
    riwayatPenyakit: "",
    obatAlergi: "",
    jaminanKesehatan: "",
    nomorJaminan: "",
    layananDipilih: "",
    dokterPilihan: "",
    tanggalKunjungan: "",
    waktuKunjungan: "",
    keluhanUtama: "",
    setujuSyarat: false
  });

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    if (!formData.setujuSyarat) {
      toast({
        title: "Persetujuan Diperlukan",
        description: "Anda harus menyetujui syarat dan ketentuan untuk melanjutkan pendaftaran.",
        variant: "destructive"
      });
      return;
    }

    // Simulate form submission
    toast({
      title: "Pendaftaran Berhasil!",
      description: "Data Anda telah tersimpan. Silakan datang ke rumah sakit sesuai jadwal yang dipilih.",
    });

    console.log("Form Data:", formData);
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const stepTitles = [
    "Data Pribadi",
    "Kontak & Keluarga",
    "Riwayat Kesehatan",
    "Jadwal & Konfirmasi"
  ];

  return (
    <div className="min-h-screen py-8 px-6 bg-hospital-gradient">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge className="mb-4 bg-medical-gradient text-white">
            <UserPlus className="w-4 h-4 mr-2" />
            Pendaftaran Online
          </Badge>
          <h1 className="text-4xl font-bold mb-4">Daftar Sebagai Pasien Baru</h1>
          <p className="text-xl text-muted-foreground">
            Lengkapi formulir berikut untuk mendaftar sebagai pasien RS Sehat Digital Indonesia
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {stepTitles.map((title, index) => (
              <div key={index} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                  currentStep > index + 1 
                    ? 'bg-green-500 text-white' 
                    : currentStep === index + 1 
                    ? 'bg-medical-500 text-white' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {currentStep > index + 1 ? <CheckCircle className="w-5 h-5" /> : index + 1}
                </div>
                <div className="ml-3 hidden md:block">
                  <div className={`text-sm font-medium ${
                    currentStep >= index + 1 ? 'text-medical-600' : 'text-gray-500'
                  }`}>
                    {title}
                  </div>
                </div>
                {index < stepTitles.length - 1 && (
                  <div className={`w-16 h-0.5 mx-4 ${
                    currentStep > index + 1 ? 'bg-green-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-medical-gradient rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">{currentStep}</span>
              </div>
              <div>
                <CardTitle>{stepTitles[currentStep - 1]}</CardTitle>
                <CardDescription>
                  Langkah {currentStep} dari {totalSteps}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Data Pribadi */}
            {currentStep === 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="namaLengkap">Nama Lengkap *</Label>
                    <Input
                      id="namaLengkap"
                      placeholder="Masukkan nama lengkap"
                      value={formData.namaLengkap}
                      onChange={(e) => handleInputChange("namaLengkap", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="nik">NIK (Nomor Induk Kependudukan) *</Label>
                    <Input
                      id="nik"
                      placeholder="Masukkan NIK 16 digit"
                      value={formData.nik}
                      onChange={(e) => handleInputChange("nik", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="tanggalLahir">Tanggal Lahir *</Label>
                    <Input
                      id="tanggalLahir"
                      type="date"
                      value={formData.tanggalLahir}
                      onChange={(e) => handleInputChange("tanggalLahir", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Jenis Kelamin *</Label>
                    <RadioGroup 
                      value={formData.jenisKelamin} 
                      onValueChange={(value) => handleInputChange("jenisKelamin", value)}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="laki-laki" id="laki-laki" />
                        <Label htmlFor="laki-laki">Laki-laki</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="perempuan" id="perempuan" />
                        <Label htmlFor="perempuan">Perempuan</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="pekerjaan">Pekerjaan</Label>
                    <Input
                      id="pekerjaan"
                      placeholder="Masukkan pekerjaan"
                      value={formData.pekerjaan}
                      onChange={(e) => handleInputChange("pekerjaan", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="pendidikan">Pendidikan Terakhir</Label>
                    <Select onValueChange={(value) => handleInputChange("pendidikan", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih pendidikan terakhir" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sd">SD</SelectItem>
                        <SelectItem value="smp">SMP</SelectItem>
                        <SelectItem value="sma">SMA/SMK</SelectItem>
                        <SelectItem value="diploma">Diploma</SelectItem>
                        <SelectItem value="s1">Sarjana (S1)</SelectItem>
                        <SelectItem value="s2">Magister (S2)</SelectItem>
                        <SelectItem value="s3">Doktor (S3)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="agama">Agama</Label>
                    <Select onValueChange={(value) => handleInputChange("agama", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih agama" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="islam">Islam</SelectItem>
                        <SelectItem value="kristen">Kristen Protestan</SelectItem>
                        <SelectItem value="katolik">Katolik</SelectItem>
                        <SelectItem value="hindu">Hindu</SelectItem>
                        <SelectItem value="buddha">Buddha</SelectItem>
                        <SelectItem value="konghucu">Konghucu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="statusPernikahan">Status Pernikahan</Label>
                    <Select onValueChange={(value) => handleInputChange("statusPernikahan", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih status pernikahan" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="belum-menikah">Belum Menikah</SelectItem>
                        <SelectItem value="menikah">Menikah</SelectItem>
                        <SelectItem value="cerai">Cerai</SelectItem>
                        <SelectItem value="janda-duda">Janda/Duda</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Kontak & Keluarga */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Phone className="w-5 h-5 text-medical-600" />
                      Informasi Kontak
                    </h3>
                    <div>
                      <Label htmlFor="alamat">Alamat Lengkap *</Label>
                      <Textarea
                        id="alamat"
                        placeholder="Masukkan alamat lengkap"
                        value={formData.alamat}
                        onChange={(e) => handleInputChange("alamat", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="nomorTelepon">Nomor Telepon *</Label>
                      <Input
                        id="nomorTelepon"
                        placeholder="Contoh: 08123456789"
                        value={formData.nomorTelepon}
                        onChange={(e) => handleInputChange("nomorTelepon", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="contoh@email.com"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <User className="w-5 h-5 text-medical-600" />
                      Kontak Darurat
                    </h3>
                    <div>
                      <Label htmlFor="namaKeluarga">Nama Keluarga/Wali *</Label>
                      <Input
                        id="namaKeluarga"
                        placeholder="Nama kontak darurat"
                        value={formData.namaKeluarga}
                        onChange={(e) => handleInputChange("namaKeluarga", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="hubunganKeluarga">Hubungan Keluarga *</Label>
                      <Select onValueChange={(value) => handleInputChange("hubunganKeluarga", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih hubungan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ayah">Ayah</SelectItem>
                          <SelectItem value="ibu">Ibu</SelectItem>
                          <SelectItem value="suami">Suami</SelectItem>
                          <SelectItem value="istri">Istri</SelectItem>
                          <SelectItem value="anak">Anak</SelectItem>
                          <SelectItem value="saudara">Saudara Kandung</SelectItem>
                          <SelectItem value="kerabat">Kerabat</SelectItem>
                          <SelectItem value="teman">Teman</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="teleponKeluarga">Nomor Telepon Keluarga *</Label>
                      <Input
                        id="teleponKeluarga"
                        placeholder="Nomor telepon kontak darurat"
                        value={formData.teleponKeluarga}
                        onChange={(e) => handleInputChange("teleponKeluarga", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Riwayat Kesehatan */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-500" />
                  Informasi Kesehatan
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="riwayatPenyakit">Riwayat Penyakit</Label>
                      <Textarea
                        id="riwayatPenyakit"
                        placeholder="Tuliskan riwayat penyakit yang pernah dialami (jika ada)"
                        value={formData.riwayatPenyakit}
                        onChange={(e) => handleInputChange("riwayatPenyakit", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="obatAlergi">Alergi Obat/Makanan</Label>
                      <Textarea
                        id="obatAlergi"
                        placeholder="Tuliskan alergi obat atau makanan (jika ada)"
                        value={formData.obatAlergi}
                        onChange={(e) => handleInputChange("obatAlergi", e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="jaminanKesehatan">Jenis Jaminan Kesehatan</Label>
                      <Select onValueChange={(value) => handleInputChange("jaminanKesehatan", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih jenis jaminan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bpjs">BPJS Kesehatan</SelectItem>
                          <SelectItem value="asuransi-swasta">Asuransi Swasta</SelectItem>
                          <SelectItem value="umum">Bayar Sendiri (Umum)</SelectItem>
                          <SelectItem value="jamkesda">Jamkesda</SelectItem>
                          <SelectItem value="lainnya">Lainnya</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="nomorJaminan">Nomor Kartu Jaminan</Label>
                      <Input
                        id="nomorJaminan"
                        placeholder="Masukkan nomor kartu (jika ada)"
                        value={formData.nomorJaminan}
                        onChange={(e) => handleInputChange("nomorJaminan", e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Jadwal & Konfirmasi */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-medical-600" />
                  Pilih Jadwal Kunjungan
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="layananDipilih">Layanan yang Dipilih *</Label>
                      <Select onValueChange={(value) => handleInputChange("layananDipilih", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih layanan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="poli-umum">Poli Umum</SelectItem>
                          <SelectItem value="poli-anak">Poli Anak</SelectItem>
                          <SelectItem value="poli-kandungan">Poli Kandungan</SelectItem>
                          <SelectItem value="poli-jantung">Poli Jantung</SelectItem>
                          <SelectItem value="poli-mata">Poli Mata</SelectItem>
                          <SelectItem value="poli-gigi">Poli Gigi</SelectItem>
                          <SelectItem value="check-up">Medical Check Up</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="dokterPilihan">Dokter Pilihan</Label>
                      <Select onValueChange={(value) => handleInputChange("dokterPilihan", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih dokter (opsional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dr-ahmad">dr. Ahmad Susanto, Sp.PD</SelectItem>
                          <SelectItem value="dr-siti">dr. Siti Nurhaliza, Sp.A</SelectItem>
                          <SelectItem value="dr-budi">dr. Budi Santoso, Sp.OG</SelectItem>
                          <SelectItem value="dr-rina">dr. Rina Melati, Sp.JP</SelectItem>
                          <SelectItem value="any">Dokter yang Tersedia</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="tanggalKunjungan">Tanggal Kunjungan *</Label>
                      <Input
                        id="tanggalKunjungan"
                        type="date"
                        value={formData.tanggalKunjungan}
                        onChange={(e) => handleInputChange("tanggalKunjungan", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="waktuKunjungan">Waktu Preferensi</Label>
                      <Select onValueChange={(value) => handleInputChange("waktuKunjungan", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih waktu" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pagi">Pagi (08:00 - 12:00)</SelectItem>
                          <SelectItem value="siang">Siang (13:00 - 17:00)</SelectItem>
                          <SelectItem value="sore">Sore (17:00 - 20:00)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="keluhanUtama">Keluhan Utama</Label>
                      <Textarea
                        id="keluhanUtama"
                        placeholder="Jelaskan keluhan atau gejala yang dialami"
                        value={formData.keluhanUtama}
                        onChange={(e) => handleInputChange("keluhanUtama", e.target.value)}
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="setujuSyarat"
                        checked={formData.setujuSyarat}
                        onCheckedChange={(checked) => handleInputChange("setujuSyarat", checked)}
                      />
                      <Label htmlFor="setujuSyarat" className="text-sm">
                        Saya menyetujui{" "}
                        <a href="/syarat-ketentuan" className="text-medical-600 hover:underline">
                          syarat dan ketentuan
                        </a>{" "}
                        serta{" "}
                        <a href="/privasi-kebijakan" className="text-medical-600 hover:underline">
                          kebijakan privasi
                        </a>{" "}
                        RS Sehat Digital Indonesia
                      </Label>
                    </div>
                    
                    <div className="bg-hospital-50 p-4 rounded-lg">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium text-amber-700 mb-2">Catatan Penting:</p>
                          <ul className="space-y-1 text-amber-600">
                            <li>• Harap datang 30 menit sebelum jadwal konsultasi</li>
                            <li>• Bawa kartu identitas dan kartu jaminan kesehatan</li>
                            <li>• Konfirmasi kehadiran akan dikirim via SMS/Email</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={currentStep === 1}
              >
                Sebelumnya
              </Button>
              
              {currentStep < totalSteps ? (
                <Button onClick={nextStep} className="bg-medical-gradient">
                  Selanjutnya
                </Button>
              ) : (
                <Button onClick={handleSubmit} className="bg-medical-gradient">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Kirim Pendaftaran
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PendaftaranOnline;
