
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User, Calendar, Phone, Mail, MapPin, Edit, FileText } from "lucide-react";
import { Link } from "react-router-dom";

const ProfilPasien = () => {
  const dataPasien = {
    nama: "Ahmad Wijaya",
    noRM: "123456",
    nik: "3175012345678901",
    tanggalLahir: "15 Januari 1985",
    jenisKelamin: "Laki-laki",
    alamat: "Jl. Kebon Jeruk No. 45, Jakarta Barat",
    telepon: "0812-3456-7890",
    email: "ahmad.wijaya@email.com",
    golDarah: "O+",
    asuransi: "BPJS Kesehatan"
  };

  const riwayatTerakhir = [
    { tanggal: "20 Mei 2025", dokter: "Dr. Siti Nurhaliza, Sp.PD", diagnosa: "Kontrol Diabetes", status: "Selesai" },
    { tanggal: "15 April 2025", dokter: "Dr. Ahmad Suryanto, Sp.B", diagnosa: "Konsultasi Bedah", status: "Selesai" },
    { tanggal: "10 Maret 2025", dokter: "Dr. Maya Sari, Sp.A", diagnosa: "Medical Check-up", status: "Selesai" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Profil Pasien</h1>
        <p className="text-lg text-gray-600">
          Kelola informasi pribadi dan riwayat medis Anda
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-6 h-6" />
                  Data Pribadi
                </CardTitle>
                <Button variant="outline" size="sm">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="text-sm font-medium text-gray-600">Nama Lengkap</label>
                  <p className="font-medium">{dataPasien.nama}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">No. Rekam Medis</label>
                  <p className="font-medium">{dataPasien.noRM}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">NIK</label>
                  <p className="font-medium">{dataPasien.nik}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Tanggal Lahir</label>
                  <p className="font-medium">{dataPasien.tanggalLahir}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Jenis Kelamin</label>
                  <p className="font-medium">{dataPasien.jenisKelamin}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Golongan Darah</label>
                  <p className="font-medium">{dataPasien.golDarah}</p>
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-gray-600">Alamat</label>
                  <p className="font-medium">{dataPasien.alamat}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Telepon</label>
                  <p className="font-medium">{dataPasien.telepon}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Email</label>
                  <p className="font-medium">{dataPasien.email}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-6 h-6" />
                Riwayat Kunjungan Terakhir
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {riwayatTerakhir.map((kunjungan, index) => (
                  <div key={index} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-medium text-gray-800">{kunjungan.diagnosa}</p>
                        <p className="text-sm text-gray-600">{kunjungan.dokter}</p>
                      </div>
                      <Badge variant="outline" className="border-medical-300 text-medical-700">
                        {kunjungan.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-500">
                      <Calendar className="w-3 h-3" />
                      {kunjungan.tanggal}
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/riwayat-pemeriksaan">
                    Lihat Semua Riwayat
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-medical-50 border-medical-200">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-medical-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-10 h-10 text-medical-600" />
                </div>
                <h3 className="font-semibold text-medical-800 mb-1">{dataPasien.nama}</h3>
                <p className="text-sm text-gray-600 mb-2">No. RM: {dataPasien.noRM}</p>
                <Badge className="bg-medical-500">{dataPasien.asuransi}</Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Menu Cepat</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/jadwal-kontrol">
                  <Calendar className="w-4 h-4 mr-2" />
                  Jadwal Kontrol
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/unduh-hasil-lab">
                  <FileText className="w-4 h-4 mr-2" />
                  Hasil Lab
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/permintaan-surat-rujukan">
                  <Mail className="w-4 h-4 mr-2" />
                  Surat Rujukan
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/konsultasi-online">
                  <Phone className="w-4 h-4 mr-2" />
                  Konsultasi Online
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-hospital-50 border-hospital-200">
            <CardContent className="p-4 text-center">
              <h3 className="font-semibold text-hospital-800 mb-2">Butuh Bantuan?</h3>
              <p className="text-sm text-gray-600 mb-3">
                Hubungi customer service untuk bantuan
              </p>
              <Button size="sm" className="w-full">
                <Phone className="w-4 h-4 mr-2" />
                (021) 123-4567
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProfilPasien;
