
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bed, Calendar, CreditCard } from "lucide-react";

const ReservasiRuang = () => {
  const kelasKamar = [
    { nama: "VIP", harga: "Rp 1.500.000/hari", tersedia: 5 },
    { nama: "Kelas I", harga: "Rp 800.000/hari", tersedia: 12 },
    { nama: "Kelas II", harga: "Rp 500.000/hari", tersedia: 18 },
    { nama: "Kelas III", harga: "Rp 300.000/hari", tersedia: 25 }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Reservasi Ruang Rawat Inap</h1>
        <p className="text-lg text-gray-600">
          Pesan kamar rawat inap sesuai kebutuhan Anda
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {kelasKamar.map((kelas, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bed className="w-5 h-5" />
                {kelas.nama}
              </CardTitle>
              <p className="text-lg font-bold text-medical-700">{kelas.harga}</p>
            </CardHeader>
            <CardContent>
              <Badge variant="outline" className="mb-4">
                {kelas.tersedia} kamar tersedia
              </Badge>
              <Button className="w-full">
                <Calendar className="w-4 h-4 mr-2" />
                Reservasi
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ReservasiRuang;
