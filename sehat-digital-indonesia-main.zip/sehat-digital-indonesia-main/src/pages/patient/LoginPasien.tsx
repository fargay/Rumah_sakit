
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { LogIn, UserPlus, Lock, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const LoginPasien = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-medical-800 mb-2">Login Pasien</h1>
          <p className="text-gray-600">
            Masuk ke akun Anda untuk mengakses layanan digital
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 justify-center">
              <LogIn className="w-6 h-6" />
              Masuk ke Akun
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Email atau No. RM</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input placeholder="email@domain.com atau 123456" className="pl-10" />
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input type="password" placeholder="Masukkan password" className="pl-10" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox id="remember" />
                <label htmlFor="remember" className="text-sm">Ingat saya</label>
              </div>
              <Link to="#" className="text-sm text-medical-600 hover:underline">
                Lupa password?
              </Link>
            </div>

            <Button className="w-full">
              <LogIn className="w-4 h-4 mr-2" />
              Masuk
            </Button>

            <div className="text-center">
              <span className="text-sm text-gray-600">Belum punya akun? </span>
              <Link 
                to="/pendaftaran-online" 
                className="text-sm text-medical-600 hover:underline font-medium"
              >
                Daftar sekarang
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-6 bg-hospital-50 border-hospital-200">
          <CardContent className="p-4">
            <h3 className="font-semibold text-hospital-800 mb-2">Akses Cepat</h3>
            <div className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/pendaftaran-online">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Daftar Pasien Baru
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                <Link to="/jadwal-praktik">
                  <LogIn className="w-4 h-4 mr-2" />
                  Lihat Jadwal Dokter
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LoginPasien;
