
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, MapPin, Phone } from "lucide-react";

const JadwalKontrol = () => {
  const jadwalKontrol = [
    {
      tanggal: "30 Mei 2025",
      waktu: "10:00",
      dokter: "Dr. Siti Nurhaliza, Sp.PD",
      poli: "Poli Penyakit Dalam",
      keperluan: "Kontrol Diabetes",
      status: "Terjadwal",
      ruang: "Poli 2 Lt. 1"
    },
    {
      tanggal: "15 Juni 2025", 
      waktu: "14:30",
      dokter: "Dr. Ahmad Suryanto, Sp.B",
      poli: "Poli Bedah",
      keperluan: "Post-Op Follow Up",
      status: "Menunggu Konfirmasi",
      ruang: "Poli 5 Lt. 2"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Jadwal Kontrol</h1>
        <p className="text-lg text-gray-600">
          Kelola jadwal kontrol dan kunjungan berikutnya
        </p>
      </div>

      <div className="space-y-6">
        {jadwalKontrol.map((jadwal, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    {jadwal.keperluan}
                  </h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {jadwal.tanggal}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {jadwal.waktu}
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      {jadwal.dokter}
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {jadwal.ruang}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge 
                    variant={jadwal.status === 'Terjadwal' ? 'default' : 'secondary'}
                    className={jadwal.status === 'Terjadwal' ? 'bg-medical-500' : ''}
                  >
                    {jadwal.status}
                  </Badge>
                  <p className="text-sm text-gray-600 mt-2">{jadwal.poli}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <Calendar className="w-4 h-4 mr-2" />
                  Reschedule
                </Button>
                <Button size="sm" variant="outline">
                  <Phone className="w-4 h-4 mr-2" />
                  Hubungi Dokter
                </Button>
                <Button size="sm">
                  Konfirmasi
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default JadwalKontrol;
