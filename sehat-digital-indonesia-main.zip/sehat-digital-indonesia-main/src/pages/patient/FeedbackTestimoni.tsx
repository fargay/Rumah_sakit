
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star, Send } from "lucide-react";

const FeedbackTestimoni = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Feedback & Testimoni</h1>
        <p className="text-lg text-gray-600">
          Berikan ulasan dan testimoni tentang pelayanan kami
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Berikan Testimoni Anda</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Rating Pelayanan</label>
            <div className="flex gap-1">
              {[1,2,3,4,5].map(num => (
                <Star key={num} className="w-6 h-6 text-yellow-400 cursor-pointer hover:scale-110" />
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">Testimoni</label>
            <Textarea placeholder="Ceritakan pengalaman Anda..." rows={5} />
          </div>
          <Button>
            <Send className="w-4 h-4 mr-2" />
            Kirim Testimoni
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeedbackTestimoni;
