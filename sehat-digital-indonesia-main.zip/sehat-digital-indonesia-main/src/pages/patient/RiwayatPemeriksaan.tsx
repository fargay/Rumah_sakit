
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileText, Calendar, User, Download, Search, Filter } from "lucide-react";

const RiwayatPemeriksaan = () => {
  const riwayatPemeriksaan = [
    {
      tanggal: "24 Mei 2025",
      waktu: "10:30",
      dokter: "Dr. Siti Nurhaliza, Sp.PD",
      poli: "Poli Penyakit Dalam", 
      diagnosa: "Diabetes Mellitus Tipe 2",
      tindakan: "Konsultasi, Cek Gula Darah",
      resep: "Metformin 500mg 2x1, Glimepiride 2mg 1x1",
      status: "Selesai",
      biaya: "Rp 250.000"
    },
    {
      tanggal: "15 April 2025",
      waktu: "14:15",
      dokter: "Dr. Ahmad Suryanto, Sp.B",
      poli: "Poli Bedah",
      diagnosa: "Hernia Inguinalis",
      tindakan: "Konsultasi Pra-Operasi, USG Abdomen",
      resep: "Paracetamol 500mg 3x1 jika nyeri",
      status: "Selesai",
      biaya: "Rp 400.000"
    },
    {
      tanggal: "20 Maret 2025",
      waktu: "09:45",
      dokter: "Dr. Maya Sari, Sp.A",
      poli: "Medical Check-up",
      diagnosa: "Sehat",
      tindakan: "MCU Eksekutif, Lab Lengkap, EKG, Rontgen",
      resep: "-",
      status: "Selesai",
      biaya: "Rp 1.500.000"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Riwayat Pemeriksaan</h1>
        <p className="text-lg text-gray-600">
          Catatan lengkap pemeriksaan dan tindakan medis Anda
        </p>
      </div>

      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input placeholder="Cari berdasarkan dokter, diagnosa..." className="pl-10" />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        {riwayatPemeriksaan.map((pemeriksaan, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg mb-2">{pemeriksaan.diagnosa}</CardTitle>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {pemeriksaan.tanggal} - {pemeriksaan.waktu}
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {pemeriksaan.dokter}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className="mb-2 bg-medical-500">{pemeriksaan.status}</Badge>
                  <p className="text-lg font-bold text-medical-700">{pemeriksaan.biaya}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h4 className="font-semibold mb-2">Poli / Unit</h4>
                  <p className="text-gray-700">{pemeriksaan.poli}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Tindakan</h4>
                  <p className="text-gray-700">{pemeriksaan.tindakan}</p>
                </div>
                <div className="md:col-span-2">
                  <h4 className="font-semibold mb-2">Resep Obat</h4>
                  <p className="text-gray-700">{pemeriksaan.resep || 'Tidak ada resep'}</p>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button size="sm" variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  Detail
                </Button>
                <Button size="sm" variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-8 bg-medical-50 border-medical-200">
        <CardContent className="p-6 text-center">
          <FileText className="w-12 h-12 text-medical-600 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-medical-800 mb-2">
            Rekam Medis Digital
          </h3>
          <p className="text-gray-600 mb-4">
            Semua catatan medis Anda tersimpan aman dan dapat diakses kapan saja
          </p>
          <div className="flex gap-4 justify-center">
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
            <Button>
              <FileText className="w-4 h-4 mr-2" />
              Minta Salinan
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RiwayatPemeriksaan;
