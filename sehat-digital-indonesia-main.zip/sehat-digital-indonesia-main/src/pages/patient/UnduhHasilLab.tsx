
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Eye } from "lucide-react";

const UnduhHasilLab = () => {
  const hasilLab = [
    { tanggal: "24 Mei 2025", jenis: "Darah Lengkap", status: "Selesai" },
    { tanggal: "20 Mei 2025", jenis: "Gula Darah", status: "Selesai" },
    { tanggal: "15 Mei 2025", jenis: "Kolesterol", status: "Proses" }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Unduh Hasil Lab</h1>
        <p className="text-lg text-gray-600">
          Akses dan unduh hasil pemeriksaan laboratorium Anda
        </p>
      </div>

      <div className="space-y-4">
        {hasilLab.map((hasil, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-semibold">{hasil.jenis}</h3>
                  <p className="text-sm text-gray-600">{hasil.tanggal}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={hasil.status === 'Selesai' ? 'default' : 'secondary'}>
                    {hasil.status}
                  </Badge>
                  {hasil.status === 'Selesai' && (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4 mr-2" />
                        Lihat
                      </Button>
                      <Button size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Unduh
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default UnduhHasilLab;
