
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Send } from "lucide-react";

const PermintaanSuratRujukan = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-medical-800 mb-4">Permintaan Surat Rujukan</h1>
        <p className="text-lg text-gray-600">
          Ajukan permintaan surat rujukan ke rumah sakit lain
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-6 h-6" />
            Form Permintaan Surat Rujukan
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm font-medium mb-2 block">Rumah Sakit Tujuan</label>
              <Input placeholder="Nama rumah sakit tujuan" />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Dokter/Spesialis Tujuan</label>
              <Input placeholder="Nama dokter atau spesialis" />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">Alasan Rujukan</label>
            <Textarea placeholder="Jelaskan alasan memerlukan rujukan..." rows={4} />
          </div>
          <Button>
            <Send className="w-4 h-4 mr-2" />
            Ajukan Permintaan
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default PermintaanSuratRujukan;
