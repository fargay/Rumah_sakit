
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { TopNavigation } from "@/components/top-navigation";

// Public Pages
import Index from "./pages/Index";
import TentangRumahSakit from "./pages/public/TentangRumahSakit";
import VisiMisi from "./pages/public/VisiMisi";
import SejarahRumahSakit from "./pages/public/SejarahRumahSakit";
import StrukturOrganisasi from "./pages/public/StrukturOrganisasi";
import DaftarDokter from "./pages/public/DaftarDokter";
import JadwalPraktik from "./pages/public/JadwalPraktik";
import LayananMedis from "./pages/public/LayananMedis";
import LayananNonMedis from "./pages/public/LayananNonMedis";
import InformasiRawatJalan from "./pages/public/InformasiRawatJalan";
import InformasiRawatInap from "./pages/public/InformasiRawatInap";
import IGD from "./pages/public/IGD";
import FasilitasSarana from "./pages/public/FasilitasSarana";
import GaleriFoto from "./pages/public/GaleriFoto";
import GaleriVideo from "./pages/public/GaleriVideo";
import ArtikelKesehatan from "./pages/public/ArtikelKesehatan";
import BeritaRumahSakit from "./pages/public/BeritaRumahSakit";
import KontakKami from "./pages/public/KontakKami";
import LokasiPeta from "./pages/public/LokasiPeta";
import FAQ from "./pages/public/FAQ";

// Patient Pages
import PendaftaranOnline from "./pages/patient/PendaftaranOnline";
import LoginPasien from "./pages/patient/LoginPasien";
import ProfilPasien from "./pages/patient/ProfilPasien";
import RiwayatPemeriksaan from "./pages/patient/RiwayatPemeriksaan";
import JadwalKontrol from "./pages/patient/JadwalKontrol";
import PermintaanSuratRujukan from "./pages/patient/PermintaanSuratRujukan";
import ReservasiRuang from "./pages/patient/ReservasiRuang";
import KonsultasiOnline from "./pages/patient/KonsultasiOnline";
import FeedbackTestimoni from "./pages/patient/FeedbackTestimoni";
import UnduhHasilLab from "./pages/patient/UnduhHasilLab";

// Admin Pages
import LoginAdmin from "./pages/admin/LoginAdmin";
import DashboardAdmin from "./pages/admin/DashboardAdmin";
import ManajemenDokter from "./pages/admin/ManajemenDokter";
import ManajemenPasien from "./pages/admin/ManajemenPasien";
import ManajemenJadwalDokter from "./pages/admin/ManajemenJadwalDokter";
import ManajemenBerita from "./pages/admin/ManajemenBerita";
import ManajemenArtikelKesehatan from "./pages/admin/ManajemenArtikelKesehatan";
import ManajemenLayanan from "./pages/admin/ManajemenLayanan";
import ManajemenFasilitas from "./pages/admin/ManajemenFasilitas";
import KelolaReservasi from "./pages/admin/KelolaReservasi";

// Staff Pages
import LoginPegawai from "./pages/staff/LoginPegawai";
import PortalPegawai from "./pages/staff/PortalPegawai";
import LaporanBulanan from "./pages/staff/LaporanBulanan";
import StatistikKunjungan from "./pages/staff/StatistikKunjungan";
import NotifikasiSistem from "./pages/staff/NotifikasiSistem";

// System Pages
import HalamanError from "./pages/system/HalamanError";
import PrivasiKebijakan from "./pages/system/PrivasiKebijakan";
import SyaratKetentuan from "./pages/system/SyaratKetentuan";
import HalamanPencarian from "./pages/system/HalamanPencarian";
import Sitemap from "./pages/system/Sitemap";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <SidebarProvider>
          <div className="min-h-screen flex w-full bg-hospital-gradient">
            <AppSidebar />
            <div className="flex-1 flex flex-col">
              <TopNavigation />
              <main className="flex-1">
                <Routes>
                  {/* Public Routes */}
                  <Route path="/" element={<Index />} />
                  <Route path="/tentang-rumah-sakit" element={<TentangRumahSakit />} />
                  <Route path="/visi-misi" element={<VisiMisi />} />
                  <Route path="/sejarah-rumah-sakit" element={<SejarahRumahSakit />} />
                  <Route path="/struktur-organisasi" element={<StrukturOrganisasi />} />
                  <Route path="/daftar-dokter" element={<DaftarDokter />} />
                  <Route path="/jadwal-praktik" element={<JadwalPraktik />} />
                  <Route path="/layanan-medis" element={<LayananMedis />} />
                  <Route path="/layanan-non-medis" element={<LayananNonMedis />} />
                  <Route path="/informasi-rawat-jalan" element={<InformasiRawatJalan />} />
                  <Route path="/informasi-rawat-inap" element={<InformasiRawatInap />} />
                  <Route path="/igd" element={<IGD />} />
                  <Route path="/fasilitas-sarana" element={<FasilitasSarana />} />
                  <Route path="/galeri-foto" element={<GaleriFoto />} />
                  <Route path="/galeri-video" element={<GaleriVideo />} />
                  <Route path="/artikel-kesehatan" element={<ArtikelKesehatan />} />
                  <Route path="/berita-rumah-sakit" element={<BeritaRumahSakit />} />
                  <Route path="/kontak-kami" element={<KontakKami />} />
                  <Route path="/lokasi-peta" element={<LokasiPeta />} />
                  <Route path="/faq" element={<FAQ />} />

                  {/* Patient Routes */}
                  <Route path="/pendaftaran-online" element={<PendaftaranOnline />} />
                  <Route path="/login-pasien" element={<LoginPasien />} />
                  <Route path="/profil-pasien" element={<ProfilPasien />} />
                  <Route path="/riwayat-pemeriksaan" element={<RiwayatPemeriksaan />} />
                  <Route path="/jadwal-kontrol" element={<JadwalKontrol />} />
                  <Route path="/permintaan-surat-rujukan" element={<PermintaanSuratRujukan />} />
                  <Route path="/reservasi-ruang" element={<ReservasiRuang />} />
                  <Route path="/konsultasi-online" element={<KonsultasiOnline />} />
                  <Route path="/feedback-testimoni" element={<FeedbackTestimoni />} />
                  <Route path="/unduh-hasil-lab" element={<UnduhHasilLab />} />

                  {/* Admin Routes */}
                  <Route path="/admin/login" element={<LoginAdmin />} />
                  <Route path="/admin/dashboard" element={<DashboardAdmin />} />
                  <Route path="/admin/manajemen-dokter" element={<ManajemenDokter />} />
                  <Route path="/admin/manajemen-pasien" element={<ManajemenPasien />} />
                  <Route path="/admin/manajemen-jadwal-dokter" element={<ManajemenJadwalDokter />} />
                  <Route path="/admin/manajemen-berita" element={<ManajemenBerita />} />
                  <Route path="/admin/manajemen-artikel-kesehatan" element={<ManajemenArtikelKesehatan />} />
                  <Route path="/admin/manajemen-layanan" element={<ManajemenLayanan />} />
                  <Route path="/admin/manajemen-fasilitas" element={<ManajemenFasilitas />} />
                  <Route path="/admin/kelola-reservasi" element={<KelolaReservasi />} />

                  {/* Staff Routes */}
                  <Route path="/staff/login" element={<LoginPegawai />} />
                  <Route path="/staff/portal" element={<PortalPegawai />} />
                  <Route path="/staff/laporan-bulanan" element={<LaporanBulanan />} />
                  <Route path="/staff/statistik-kunjungan" element={<StatistikKunjungan />} />
                  <Route path="/staff/notifikasi-sistem" element={<NotifikasiSistem />} />

                  {/* System Routes */}
                  <Route path="/error" element={<HalamanError />} />
                  <Route path="/privasi-kebijakan" element={<PrivasiKebijakan />} />
                  <Route path="/syarat-ketentuan" element={<SyaratKetentuan />} />
                  <Route path="/pencarian" element={<HalamanPencarian />} />
                  <Route path="/sitemap" element={<Sitemap />} />

                  {/* 404 */}
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </main>
            </div>
          </div>
        </SidebarProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
