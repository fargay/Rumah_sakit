
import {
  Home,
  Building2,
  Stethoscope,
  Calendar,
  MapPin,
  Users,
  FileText,
  Settings,
  UserCheck,
  ClipboardList,
  Phone,
  HelpCircle,
  Heart,
  Activity,
  Shield,
  Search,
  UserPlus,
  LogIn,
  ChevronRight,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const menuItems = [
  {
    title: "Beranda",
    url: "/",
    icon: Home,
  },
  {
    title: "Tentang Kami",
    icon: Building2,
    items: [
      { title: "Profil Rumah Sakit", url: "/tentang-rumah-sakit" },
      { title: "Visi & Misi", url: "/visi-misi" },
      { title: "Sejarah", url: "/sejarah-rumah-sakit" },
      { title: "Struktur Organisasi", url: "/struktur-organisasi" },
    ],
  },
  {
    title: "Layanan Medis",
    icon: Stethoscope,
    items: [
      { title: "Daftar Dokter", url: "/daftar-dokter" },
      { title: "Jadwal Praktik", url: "/jadwal-praktik" },
      { title: "Layanan Medis", url: "/layanan-medis" },
      { title: "Layanan Non-Medis", url: "/layanan-non-medis" },
      { title: "IGD 24 Jam", url: "/igd" },
    ],
  },
  {
    title: "Informasi Pasien",
    icon: UserCheck,
    items: [
      { title: "Rawat Jalan", url: "/informasi-rawat-jalan" },
      { title: "Rawat Inap", url: "/informasi-rawat-inap" },
      { title: "Fasilitas & Sarana", url: "/fasilitas-sarana" },
    ],
  },
  {
    title: "Layanan Online",
    icon: Activity,
    items: [
      { title: "Pendaftaran Online", url: "/pendaftaran-online" },
      { title: "Login Pasien", url: "/login-pasien" },
      { title: "Konsultasi Online", url: "/konsultasi-online" },
      { title: "Reservasi Ruang", url: "/reservasi-ruang" },
    ],
  },
  {
    title: "Galeri & Media",
    icon: FileText,
    items: [
      { title: "Galeri Foto", url: "/galeri-foto" },
      { title: "Galeri Video", url: "/galeri-video" },
      { title: "Artikel Kesehatan", url: "/artikel-kesehatan" },
      { title: "Berita Rumah Sakit", url: "/berita-rumah-sakit" },
    ],
  },
  {
    title: "Kontak & Bantuan",
    icon: Phone,
    items: [
      { title: "Kontak Kami", url: "/kontak-kami" },
      { title: "Lokasi & Peta", url: "/lokasi-peta" },
      { title: "FAQ", url: "/faq" },
    ],
  },
];

const adminItems = [
  {
    title: "Admin Panel",
    icon: Settings,
    items: [
      { title: "Login Admin", url: "/admin/login" },
      { title: "Dashboard Admin", url: "/admin/dashboard" },
      { title: "Manajemen Dokter", url: "/admin/manajemen-dokter" },
      { title: "Manajemen Pasien", url: "/admin/manajemen-pasien" },
    ],
  },
  {
    title: "Portal Pegawai",
    icon: Users,
    items: [
      { title: "Login Pegawai", url: "/staff/login" },
      { title: "Portal Pegawai", url: "/staff/portal" },
      { title: "Laporan Bulanan", url: "/staff/laporan-bulanan" },
    ],
  },
];

export function AppSidebar() {
  const location = useLocation();

  return (
    <Sidebar className="border-r bg-white/80 backdrop-blur-sm">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-medical-gradient rounded-lg flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-lg text-hospital-800">RS Sehat Digital</h2>
            <p className="text-sm text-muted-foreground">Rumah Sakit Modern</p>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menu Utama</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="w-full justify-between hover:bg-medical-50">
                          <div className="flex items-center gap-2">
                            <item.icon className="w-4 h-4" />
                            <span>{item.title}</span>
                          </div>
                          <ChevronRight className="w-4 h-4" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton asChild>
                                <Link 
                                  to={subItem.url}
                                  className={`hover:bg-hospital-50 ${
                                    location.pathname === subItem.url ? 'bg-medical-gradient text-white' : ''
                                  }`}
                                >
                                  {subItem.title}
                                </Link>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton asChild>
                      <Link 
                        to={item.url}
                        className={`hover:bg-medical-50 ${
                          location.pathname === item.url ? 'bg-medical-gradient text-white' : ''
                        }`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Sistem Internal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <Collapsible>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton className="w-full justify-between hover:bg-medical-50">
                        <div className="flex items-center gap-2">
                          <item.icon className="w-4 h-4" />
                          <span>{item.title}</span>
                        </div>
                        <ChevronRight className="w-4 h-4" />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.items.map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                            <SidebarMenuSubButton asChild>
                              <Link 
                                to={subItem.url}
                                className={`hover:bg-hospital-50 ${
                                  location.pathname === subItem.url ? 'bg-medical-gradient text-white' : ''
                                }`}
                              >
                                {subItem.title}
                              </Link>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </Collapsible>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Shield className="w-4 h-4" />
          <span>Sistem Aman & Terpercaya</span>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
