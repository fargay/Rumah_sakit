
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Search, UserPlus, LogIn, Phone } from "lucide-react";
import { Link } from "react-router-dom";

export function TopNavigation() {
  return (
    <header className="border-b bg-white/90 backdrop-blur-sm sticky top-0 z-40">
      <div className="flex h-16 items-center px-4 gap-4">
        <SidebarTrigger className="hover:bg-medical-50" />
        
        <div className="flex-1 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-hospital-100 text-hospital-800">
              🏥 Layanan 24 Jam
            </Badge>
            <Badge variant="outline" className="text-medical-700 border-medical-200">
              🩺 IGD Siaga
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/pencarian">
                <Search className="w-4 h-4" />
              </Link>
            </Button>
            
            <Button variant="ghost" size="sm">
              <Bell className="w-4 h-4" />
            </Button>

            <Button variant="outline" size="sm" asChild>
              <Link to="/pendaftaran-online">
                <UserPlus className="w-4 h-4 mr-2" />
                Daftar
              </Link>
            </Button>

            <Button variant="default" size="sm" className="bg-medical-gradient hover:opacity-90" asChild>
              <Link to="/login-pasien">
                <LogIn className="w-4 h-4 mr-2" />
                Masuk
              </Link>
            </Button>

            <Button variant="destructive" size="sm" asChild>
              <Link to="/kontak-kami">
                <Phone className="w-4 h-4 mr-2" />
                Darurat
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
